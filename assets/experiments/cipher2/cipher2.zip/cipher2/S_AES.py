import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np


class SAES:
    def __init__(self):
        # S盒和逆S盒
        self.S_BOX = [
            [0x9, 0x4, 0xA, 0xB],
            [0xD, 0x1, 0x8, 0x5],
            [0x6, 0x2, 0x0, 0x3],
            [0xC, 0xE, 0xF, 0x7]
        ]

        self.INV_S_BOX = [
            [0xA, 0x5, 0x9, 0xB],
            [0x1, 0x7, 0x8, 0xF],
            [0x6, 0x0, 0x2, 0x3],
            [0xC, 0x4, 0xD, 0xE]
        ]

        # 轮常数
        self.RCON = [0x80, 0x30]

    def gf_mult(self, a, b):
        """在GF(2^4)上的乘法"""
        result = 0
        for _ in range(4):
            if b & 1:
                result ^= a
            hi_bit_set = a & 0x8
            a <<= 1
            a &= 0xF
            if hi_bit_set:
                a ^= 0x3
            b >>= 1
        return result

    def sub_nibbles(self, state, inverse=False):
        """半字节替换"""
        s_box = self.INV_S_BOX if inverse else self.S_BOX
        result = []
        for nibble in state:
            row = (nibble >> 2) & 0x3
            col = nibble & 0x3
            result.append(s_box[row][col])
        return result

    def shift_rows(self, state):
        """行移位"""
        return [state[0], state[1], state[3], state[2]]

    def mix_columns(self, state, inverse=False):
        """列混淆"""
        result = [0] * 4
        if inverse:
            # 逆列混淆矩阵
            result[0] = self.gf_mult(0x9, state[0]) ^ self.gf_mult(0x2, state[2])
            result[1] = self.gf_mult(0x9, state[1]) ^ self.gf_mult(0x2, state[3])
            result[2] = self.gf_mult(0x2, state[0]) ^ self.gf_mult(0x9, state[2])
            result[3] = self.gf_mult(0x2, state[1]) ^ self.gf_mult(0x9, state[3])
        else:
            # 列混淆矩阵
            result[0] = state[0] ^ self.gf_mult(0x4, state[2])
            result[1] = state[1] ^ self.gf_mult(0x4, state[3])
            result[2] = self.gf_mult(0x4, state[0]) ^ state[2]
            result[3] = self.gf_mult(0x4, state[1]) ^ state[3]
        return result

    def key_expansion(self, key):
        """密钥扩展"""
        # 将16位密钥分成4个半字节
        w = [(key >> 12) & 0xF, (key >> 8) & 0xF,
             (key >> 4) & 0xF, key & 0xF]

        # 生成扩展密钥
        w.append(w[0] ^ self.RCON[0] ^ self.S_BOX[(w[3] >> 2) & 0x3][w[3] & 0x3])
        w.append(w[1] ^ w[4])
        w.append(w[2] ^ w[5])
        w.append(w[3] ^ w[6])

        w.append(w[4] ^ self.RCON[1] ^ self.S_BOX[(w[7] >> 2) & 0x3][w[7] & 0x3])
        w.append(w[5] ^ w[8])
        w.append(w[6] ^ w[9])
        w.append(w[7] ^ w[10])

        # 组织成轮密钥
        k0 = (w[0] << 12) | (w[1] << 8) | (w[2] << 4) | w[3]
        k1 = (w[4] << 12) | (w[5] << 8) | (w[6] << 4) | w[7]
        k2 = (w[8] << 12) | (w[9] << 8) | (w[10] << 4) | w[11]

        return k0, k1, k2

    def add_round_key(self, state, key):
        """轮密钥加"""
        key_nibbles = [(key >> 12) & 0xF, (key >> 8) & 0xF,
                       (key >> 4) & 0xF, key & 0xF]
        return [state[i] ^ key_nibbles[i] for i in range(4)]

    def encrypt_block(self, plaintext, key):
        """加密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位明文分成4个半字节
        state = [(plaintext >> 12) & 0xF, (plaintext >> 8) & 0xF,
                 (plaintext >> 4) & 0xF, plaintext & 0xF]

        # 第0轮轮密钥加
        state = self.add_round_key(state, k0)

        # 第1轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.mix_columns(state)
        state = self.add_round_key(state, k1)

        # 第2轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.add_round_key(state, k2)

        # 组合成16位密文
        ciphertext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return ciphertext

    def decrypt_block(self, ciphertext, key):
        """解密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位密文分成4个半字节
        state = [(ciphertext >> 12) & 0xF, (ciphertext >> 8) & 0xF,
                 (ciphertext >> 4) & 0xF, ciphertext & 0xF]

        # 逆向第2轮
        state = self.add_round_key(state, k2)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第1轮
        state = self.add_round_key(state, k1)
        state = self.mix_columns(state, inverse=True)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第0轮
        state = self.add_round_key(state, k0)

        # 组合成16位明文
        plaintext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return plaintext

    def text_to_blocks(self, text):
        """将文本转换为16位数据块列表"""
        blocks = []
        # 确保文本长度为偶数
        if len(text) % 2 != 0:
            text += ' '  # 填充空格

        for i in range(0, len(text), 2):
            block = (ord(text[i]) << 8) | ord(text[i + 1])
            blocks.append(block)

        return blocks

    def blocks_to_text(self, blocks):
        """将16位数据块列表转换为文本"""
        text = ""
        for block in blocks:
            char1 = (block >> 8) & 0xFF
            char2 = block & 0xFF
            text += chr(char1) + chr(char2)
        return text

    def encrypt_text(self, plaintext, key):
        """加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.encrypt_block(block, key) for block in blocks]
        return self.blocks_to_text(cipher_blocks)

    def decrypt_text(self, ciphertext, key):
        """解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.decrypt_block(block, key) for block in blocks]
        return self.blocks_to_text(plain_blocks)


class SAESGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("S-AES加密解密工具")
        self.root.geometry("600x500")

        self.saes = SAES()

        self.setup_ui()

    def setup_ui(self):
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 输入类型选择
        type_frame = ttk.LabelFrame(main_frame, text="输入类型", padding="5")
        type_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.input_type = tk.StringVar(value="binary")
        ttk.Radiobutton(type_frame, text="16位二进制", variable=self.input_type,
                        value="binary", command=self.on_type_change).grid(row=0, column=0, padx=5)
        ttk.Radiobutton(type_frame, text="ASCII文本", variable=self.input_type,
                        value="text", command=self.on_type_change).grid(row=0, column=1, padx=5)

        # 密钥输入
        key_frame = ttk.LabelFrame(main_frame, text="密钥", padding="5")
        key_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(key_frame, text="16位密钥:").grid(row=0, column=0, sticky=tk.W)
        self.key_entry = ttk.Entry(key_frame, width=20)
        self.key_entry.grid(row=0, column=1, padx=5)
        self.key_entry.insert(0, "1010111100110001")

        # 输入数据
        input_frame = ttk.LabelFrame(main_frame, text="输入数据", padding="5")
        input_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.input_label = ttk.Label(input_frame, text="16位数据:")
        self.input_label.grid(row=0, column=0, sticky=tk.W)

        self.input_text = tk.Text(input_frame, height=4, width=50)
        self.input_text.grid(row=1, column=0, columnspan=2, pady=5)
        self.input_text.insert("1.0", "0110111101101011")

        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="加密", command=self.encrypt).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="解密", command=self.decrypt).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="清空", command=self.clear).grid(row=0, column=2, padx=5)

        # 输出数据
        output_frame = ttk.LabelFrame(main_frame, text="输出结果", padding="5")
        output_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.output_text = tk.Text(output_frame, height=6, width=50)
        self.output_text.grid(row=0, column=0, columnspan=2, pady=5)

        # 状态栏
        self.status_var = tk.StringVar()
        self.status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        self.status_bar.grid(row=5, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.status_var.set("就绪")

    def on_type_change(self):
        """切换输入类型时更新界面"""
        if self.input_type.get() == "binary":
            self.input_label.config(text="16位数据:")
            self.input_text.delete("1.0", tk.END)
            self.input_text.insert("1.0", "0110111101101011")
        else:
            self.input_label.config(text="ASCII文本:")
            self.input_text.delete("1.0", tk.END)
            self.input_text.insert("1.0", "Hello World!")

    def validate_binary(self, text):
        """验证二进制输入"""
        if len(text) != 16:
            return False
        for char in text:
            if char not in '01':
                return False
        return True

    def validate_key(self, key):
        """验证密钥"""
        return self.validate_binary(key)

    def encrypt(self):
        """加密操作"""
        try:
            key_str = self.key_entry.get().strip()
            if not self.validate_key(key_str):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key = int(key_str, 2)
            input_data = self.input_text.get("1.0", tk.END).strip()

            if self.input_type.get() == "binary":
                if not self.validate_binary(input_data):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                plaintext = int(input_data, 2)
                ciphertext = self.saes.encrypt_block(plaintext, key)
                output_bin = format(ciphertext, '016b')
                self.output_text.delete("1.0", tk.END)
                self.output_text.insert("1.0", f"密文(二进制): {output_bin}\n")
                self.output_text.insert(tk.END, f"密文(十六进制): {format(ciphertext, '04X')}")

            else:
                ciphertext = self.saes.encrypt_text(input_data, key)
                self.output_text.delete("1.0", tk.END)
                self.output_text.insert("1.0", f"密文: {ciphertext}\n")
                # 显示十六进制表示
                hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
                self.output_text.insert(tk.END, f"十六进制: {hex_representation}")

            self.status_var.set("加密完成")

        except Exception as e:
            messagebox.showerror("错误", f"加密过程中发生错误: {str(e)}")

    def decrypt(self):
        """解密操作"""
        try:
            key_str = self.key_entry.get().strip()
            if not self.validate_key(key_str):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key = int(key_str, 2)
            input_data = self.input_text.get("1.0", tk.END).strip()

            if self.input_type.get() == "binary":
                if not self.validate_binary(input_data):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                ciphertext = int(input_data, 2)
                plaintext = self.saes.decrypt_block(ciphertext, key)
                output_bin = format(plaintext, '016b')
                self.output_text.delete("1.0", tk.END)
                self.output_text.insert("1.0", f"明文(二进制): {output_bin}\n")

                # 尝试显示ASCII字符
                char1 = chr((plaintext >> 8) & 0xFF)
                char2 = chr(plaintext & 0xFF)
                if char1.isprintable() and char2.isprintable():
                    self.output_text.insert(tk.END, f"ASCII字符: '{char1}{char2}'")
                else:
                    self.output_text.insert(tk.END, "无法显示为可打印ASCII字符")

            else:
                plaintext = self.saes.decrypt_text(input_data, key)
                self.output_text.delete("1.0", tk.END)
                self.output_text.insert("1.0", f"明文: {plaintext}")

            self.status_var.set("解密完成")

        except Exception as e:
            messagebox.showerror("错误", f"解密过程中发生错误: {str(e)}")

    def clear(self):
        """清空输入输出"""
        self.input_text.delete("1.0", tk.END)
        self.output_text.delete("1.0", tk.END)
        self.status_var.set("已清空")


def main():
    root = tk.Tk()
    app = SAESGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()