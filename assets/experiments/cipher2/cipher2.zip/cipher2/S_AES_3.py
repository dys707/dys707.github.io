import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
from itertools import product


class SAES:
    def __init__(self):
        # S盒和逆S盒
        self.S_BOX = [
            [0x9, 0x4, 0xA, 0xB],
            [0xD, 0x1, 0x8, 0x5],
            [0x6, 0x2, 0x0, 0x3],
            [0xC, 0xE, 0xF, 0x7]
        ]

        self.INV_S_BOX = [
            [0xA, 0x5, 0x9, 0xB],
            [0x1, 0x7, 0x8, 0xF],
            [0x6, 0x0, 0x2, 0x3],
            [0xC, 0x4, 0xD, 0xE]
        ]

        # 轮常数
        self.RCON = [0x80, 0x30]

    def gf_mult(self, a, b):
        """在GF(2^4)上的乘法"""
        result = 0
        for _ in range(4):
            if b & 1:
                result ^= a
            hi_bit_set = a & 0x8
            a <<= 1
            a &= 0xF
            if hi_bit_set:
                a ^= 0x3
            b >>= 1
        return result

    def sub_nibbles(self, state, inverse=False):
        """半字节替换"""
        s_box = self.INV_S_BOX if inverse else self.S_BOX
        result = []
        for nibble in state:
            row = (nibble >> 2) & 0x3
            col = nibble & 0x3
            result.append(s_box[row][col])
        return result

    def shift_rows(self, state):
        """行移位"""
        return [state[0], state[1], state[3], state[2]]

    def mix_columns(self, state, inverse=False):
        """列混淆"""
        result = [0] * 4
        if inverse:
            # 逆列混淆矩阵
            result[0] = self.gf_mult(0x9, state[0]) ^ self.gf_mult(0x2, state[2])
            result[1] = self.gf_mult(0x9, state[1]) ^ self.gf_mult(0x2, state[3])
            result[2] = self.gf_mult(0x2, state[0]) ^ self.gf_mult(0x9, state[2])
            result[3] = self.gf_mult(0x2, state[1]) ^ self.gf_mult(0x9, state[3])
        else:
            # 列混淆矩阵
            result[0] = state[0] ^ self.gf_mult(0x4, state[2])
            result[1] = state[1] ^ self.gf_mult(0x4, state[3])
            result[2] = self.gf_mult(0x4, state[0]) ^ state[2]
            result[3] = self.gf_mult(0x4, state[1]) ^ state[3]
        return result

    def key_expansion(self, key):
        """密钥扩展"""
        # 将16位密钥分成4个半字节
        w = [(key >> 12) & 0xF, (key >> 8) & 0xF,
             (key >> 4) & 0xF, key & 0xF]

        # 生成扩展密钥
        w.append(w[0] ^ self.RCON[0] ^ self.S_BOX[(w[3] >> 2) & 0x3][w[3] & 0x3])
        w.append(w[1] ^ w[4])
        w.append(w[2] ^ w[5])
        w.append(w[3] ^ w[6])

        w.append(w[4] ^ self.RCON[1] ^ self.S_BOX[(w[7] >> 2) & 0x3][w[7] & 0x3])
        w.append(w[5] ^ w[8])
        w.append(w[6] ^ w[9])
        w.append(w[7] ^ w[10])

        # 组织成轮密钥
        k0 = (w[0] << 12) | (w[1] << 8) | (w[2] << 4) | w[3]
        k1 = (w[4] << 12) | (w[5] << 8) | (w[6] << 4) | w[7]
        k2 = (w[8] << 12) | (w[9] << 8) | (w[10] << 4) | w[11]

        return k0, k1, k2

    def add_round_key(self, state, key):
        """轮密钥加"""
        key_nibbles = [(key >> 12) & 0xF, (key >> 8) & 0xF,
                       (key >> 4) & 0xF, key & 0xF]
        return [state[i] ^ key_nibbles[i] for i in range(4)]

    def encrypt_block(self, plaintext, key):
        """加密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位明文分成4个半字节
        state = [(plaintext >> 12) & 0xF, (plaintext >> 8) & 0xF,
                 (plaintext >> 4) & 0xF, plaintext & 0xF]

        # 第0轮轮密钥加
        state = self.add_round_key(state, k0)

        # 第1轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.mix_columns(state)
        state = self.add_round_key(state, k1)

        # 第2轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.add_round_key(state, k2)

        # 组合成16位密文
        ciphertext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return ciphertext

    def decrypt_block(self, ciphertext, key):
        """解密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位密文分成4个半字节
        state = [(ciphertext >> 12) & 0xF, (ciphertext >> 8) & 0xF,
                 (ciphertext >> 4) & 0xF, ciphertext & 0xF]

        # 逆向第2轮
        state = self.add_round_key(state, k2)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第1轮
        state = self.add_round_key(state, k1)
        state = self.mix_columns(state, inverse=True)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第0轮
        state = self.add_round_key(state, k0)

        # 组合成16位明文
        plaintext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return plaintext

    def double_encrypt_block(self, plaintext, key1, key2):
        """双重加密: E(K2, E(K1, P))"""
        intermediate = self.encrypt_block(plaintext, key1)
        return self.encrypt_block(intermediate, key2)

    def double_decrypt_block(self, ciphertext, key1, key2):
        """双重解密: D(K1, D(K2, C))"""
        intermediate = self.decrypt_block(ciphertext, key2)
        return self.decrypt_block(intermediate, key1)

    def triple_encrypt_block(self, plaintext, key1, key2, key3):
        """三重加密: E(K3, D(K2, E(K1, P)))"""
        step1 = self.encrypt_block(plaintext, key1)
        step2 = self.decrypt_block(step1, key2)
        return self.encrypt_block(step2, key3)

    def triple_decrypt_block(self, ciphertext, key1, key2, key3):
        """三重解密: D(K1, E(K2, D(K3, C)))"""
        step1 = self.decrypt_block(ciphertext, key3)
        step2 = self.encrypt_block(step1, key2)
        return self.decrypt_block(step2, key1)

    def text_to_blocks(self, text):
        """将文本转换为16位数据块列表"""
        blocks = []
        # 确保文本长度为偶数
        if len(text) % 2 != 0:
            text += ' '  # 填充空格

        for i in range(0, len(text), 2):
            block = (ord(text[i]) << 8) | ord(text[i + 1])
            blocks.append(block)

        return blocks

    def blocks_to_text(self, blocks):
        """将16位数据块列表转换为文本"""
        text = ""
        for block in blocks:
            char1 = (block >> 8) & 0xFF
            char2 = block & 0xFF
            text += chr(char1) + chr(char2)
        return text

    def encrypt_text(self, plaintext, key):
        """加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.encrypt_block(block, key) for block in blocks]
        return self.blocks_to_text(cipher_blocks)

    def decrypt_text(self, ciphertext, key):
        """解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.decrypt_block(block, key) for block in blocks]
        return self.blocks_to_text(plain_blocks)

    def double_encrypt_text(self, plaintext, key1, key2):
        """双重加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.double_encrypt_block(block, key1, key2) for block in blocks]
        return self.blocks_to_text(cipher_blocks)

    def double_decrypt_text(self, ciphertext, key1, key2):
        """双重解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.double_decrypt_block(block, key1, key2) for block in blocks]
        return self.blocks_to_text(plain_blocks)

    def triple_encrypt_text(self, plaintext, key1, key2, key3):
        """三重加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.triple_encrypt_block(block, key1, key2, key3) for block in blocks]
        return self.blocks_to_text(cipher_blocks)

    def triple_decrypt_text(self, ciphertext, key1, key2, key3):
        """三重解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.triple_decrypt_block(block, key1, key2, key3) for block in blocks]
        return self.blocks_to_text(plain_blocks)


class MeetInTheMiddleAttack:
    def __init__(self, saes):
        self.saes = saes

    def attack(self, plaintexts, ciphertexts, max_keys=100):
        """
        中间相遇攻击
        plaintexts: 明文字符串列表
        ciphertexts: 密文字符串列表
        max_keys: 返回的最大可能密钥数量
        """
        if len(plaintexts) != len(ciphertexts):
            raise ValueError("明密文对数量不匹配")

        # 将所有明密文对转换为16位整数
        plain_blocks_list = []
        cipher_blocks_list = []

        for i in range(len(plaintexts)):
            plain_blocks = self.saes.text_to_blocks(plaintexts[i])
            cipher_blocks = self.saes.text_to_blocks(ciphertexts[i])

            if len(plain_blocks) != len(cipher_blocks):
                raise ValueError(f"明密文对 {i} 长度不匹配")

            plain_blocks_list.append(plain_blocks)
            cipher_blocks_list.append(cipher_blocks)

        # 构建加密表: K1 -> 中间状态
        encryption_table = {}

        # 遍历所有可能的K1 (16位密钥，共65536种可能)
        for k1 in range(65536):
            intermediate_states = []

            # 对每个明文块进行加密
            for plain_blocks in plain_blocks_list:
                states = []
                for block in plain_blocks:
                    intermediate = self.saes.encrypt_block(block, k1)
                    states.append(intermediate)
                intermediate_states.append(tuple(states))

            # 使用中间状态作为键，存储K1
            key = tuple(intermediate_states)
            if key in encryption_table:
                encryption_table[key].append(k1)
            else:
                encryption_table[key] = [k1]

        # 查找匹配的密钥对
        possible_keys = []

        # 遍历所有可能的K2
        for k2 in range(65536):
            # 对每个密文块进行解密得到中间状态
            decrypted_states = []

            for cipher_blocks in cipher_blocks_list:
                states = []
                for block in cipher_blocks:
                    intermediate = self.saes.decrypt_block(block, k2)
                    states.append(intermediate)
                decrypted_states.append(tuple(states))

            # 检查是否存在K1使得加密后的中间状态等于解密后的中间状态
            key = tuple(decrypted_states)
            if key in encryption_table:
                for k1 in encryption_table[key]:
                    possible_keys.append((k1, k2))

                    # 如果找到足够多的密钥对，提前返回
                    if len(possible_keys) >= max_keys:
                        return possible_keys

        return possible_keys


class SAESGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("S-AES加密解密工具 - 支持多重加密")
        self.root.geometry("700x600")

        self.saes = SAES()
        self.mitm_attack = MeetInTheMiddleAttack(self.saes)

        self.setup_ui()

    def setup_ui(self):
        # 创建选项卡
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)

        # 单重加密选项卡
        single_frame = ttk.Frame(notebook, padding="10")
        notebook.add(single_frame, text="单重加密")
        self.setup_single_encryption_ui(single_frame)

        # 双重加密选项卡
        double_frame = ttk.Frame(notebook, padding="10")
        notebook.add(double_frame, text="双重加密")
        self.setup_double_encryption_ui(double_frame)

        # 三重加密选项卡
        triple_frame = ttk.Frame(notebook, padding="10")
        notebook.add(triple_frame, text="三重加密")
        self.setup_triple_encryption_ui(triple_frame)

        # 中间相遇攻击选项卡
        attack_frame = ttk.Frame(notebook, padding="10")
        notebook.add(attack_frame, text="中间相遇攻击")
        self.setup_attack_ui(attack_frame)

    def setup_single_encryption_ui(self, parent):
        # 输入类型选择
        type_frame = ttk.LabelFrame(parent, text="输入类型", padding="5")
        type_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.single_input_type = tk.StringVar(value="binary")
        ttk.Radiobutton(type_frame, text="16位二进制", variable=self.single_input_type,
                        value="binary", command=self.on_single_type_change).grid(row=0, column=0, padx=5)
        ttk.Radiobutton(type_frame, text="ASCII文本", variable=self.single_input_type,
                        value="text", command=self.on_single_type_change).grid(row=0, column=1, padx=5)

        # 密钥输入
        key_frame = ttk.LabelFrame(parent, text="密钥", padding="5")
        key_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(key_frame, text="16位密钥:").grid(row=0, column=0, sticky=tk.W)
        self.single_key_entry = ttk.Entry(key_frame, width=20)
        self.single_key_entry.grid(row=0, column=1, padx=5)
        self.single_key_entry.insert(0, "1010111100110001")

        # 输入数据
        input_frame = ttk.LabelFrame(parent, text="输入数据", padding="5")
        input_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.single_input_label = ttk.Label(input_frame, text="16位数据:")
        self.single_input_label.grid(row=0, column=0, sticky=tk.W)

        self.single_input_text = tk.Text(input_frame, height=4, width=60)
        self.single_input_text.grid(row=1, column=0, columnspan=2, pady=5)
        self.single_input_text.insert("1.0", "0110111101101011")

        # 按钮框架
        button_frame = ttk.Frame(parent)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="加密", command=self.single_encrypt).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="解密", command=self.single_decrypt).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="清空", command=self.single_clear).grid(row=0, column=2, padx=5)

        # 输出数据
        output_frame = ttk.LabelFrame(parent, text="输出结果", padding="5")
        output_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.single_output_text = tk.Text(output_frame, height=6, width=60)
        self.single_output_text.grid(row=0, column=0, columnspan=2, pady=5)

    def setup_double_encryption_ui(self, parent):
        # 输入类型选择
        type_frame = ttk.LabelFrame(parent, text="输入类型", padding="5")
        type_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.double_input_type = tk.StringVar(value="binary")
        ttk.Radiobutton(type_frame, text="16位二进制", variable=self.double_input_type,
                        value="binary", command=self.on_double_type_change).grid(row=0, column=0, padx=5)
        ttk.Radiobutton(type_frame, text="ASCII文本", variable=self.double_input_type,
                        value="text", command=self.on_double_type_change).grid(row=0, column=1, padx=5)

        # 密钥输入
        key_frame = ttk.LabelFrame(parent, text="密钥 (32位)", padding="5")
        key_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(key_frame, text="K1 (16位):").grid(row=0, column=0, sticky=tk.W)
        self.double_key1_entry = ttk.Entry(key_frame, width=20)
        self.double_key1_entry.grid(row=0, column=1, padx=5)
        self.double_key1_entry.insert(0, "1010111100110001")

        ttk.Label(key_frame, text="K2 (16位):").grid(row=1, column=0, sticky=tk.W)
        self.double_key2_entry = ttk.Entry(key_frame, width=20)
        self.double_key2_entry.grid(row=1, column=1, padx=5)
        self.double_key2_entry.insert(0, "1100110011001100")

        # 输入数据
        input_frame = ttk.LabelFrame(parent, text="输入数据", padding="5")
        input_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.double_input_label = ttk.Label(input_frame, text="16位数据:")
        self.double_input_label.grid(row=0, column=0, sticky=tk.W)

        self.double_input_text = tk.Text(input_frame, height=4, width=60)
        self.double_input_text.grid(row=1, column=0, columnspan=2, pady=5)
        self.double_input_text.insert("1.0", "0110111101101011")

        # 按钮框架
        button_frame = ttk.Frame(parent)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="加密", command=self.double_encrypt).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="解密", command=self.double_decrypt).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="清空", command=self.double_clear).grid(row=0, column=2, padx=5)

        # 输出数据
        output_frame = ttk.LabelFrame(parent, text="输出结果", padding="5")
        output_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.double_output_text = tk.Text(output_frame, height=6, width=60)
        self.double_output_text.grid(row=0, column=0, columnspan=2, pady=5)

    def setup_triple_encryption_ui(self, parent):
        # 输入类型选择
        type_frame = ttk.LabelFrame(parent, text="输入类型", padding="5")
        type_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.triple_input_type = tk.StringVar(value="binary")
        ttk.Radiobutton(type_frame, text="16位二进制", variable=self.triple_input_type,
                        value="binary", command=self.on_triple_type_change).grid(row=0, column=0, padx=5)
        ttk.Radiobutton(type_frame, text="ASCII文本", variable=self.triple_input_type,
                        value="text", command=self.on_triple_type_change).grid(row=0, column=1, padx=5)

        # 密钥输入
        key_frame = ttk.LabelFrame(parent, text="密钥 (48位)", padding="5")
        key_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(key_frame, text="K1 (16位):").grid(row=0, column=0, sticky=tk.W)
        self.triple_key1_entry = ttk.Entry(key_frame, width=20)
        self.triple_key1_entry.grid(row=0, column=1, padx=5)
        self.triple_key1_entry.insert(0, "1010111100110001")

        ttk.Label(key_frame, text="K2 (16位):").grid(row=1, column=0, sticky=tk.W)
        self.triple_key2_entry = ttk.Entry(key_frame, width=20)
        self.triple_key2_entry.grid(row=1, column=1, padx=5)
        self.triple_key2_entry.insert(0, "1100110011001100")

        ttk.Label(key_frame, text="K3 (16位):").grid(row=2, column=0, sticky=tk.W)
        self.triple_key3_entry = ttk.Entry(key_frame, width=20)
        self.triple_key3_entry.grid(row=2, column=1, padx=5)
        self.triple_key3_entry.insert(0, "1111000011110000")

        # 输入数据
        input_frame = ttk.LabelFrame(parent, text="输入数据", padding="5")
        input_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.triple_input_label = ttk.Label(input_frame, text="16位数据:")
        self.triple_input_label.grid(row=0, column=0, sticky=tk.W)

        self.triple_input_text = tk.Text(input_frame, height=4, width=60)
        self.triple_input_text.grid(row=1, column=0, columnspan=2, pady=5)
        self.triple_input_text.insert("1.0", "0110111101101011")

        # 按钮框架
        button_frame = ttk.Frame(parent)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="加密", command=self.triple_encrypt).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="解密", command=self.triple_decrypt).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="清空", command=self.triple_clear).grid(row=0, column=2, padx=5)

        # 输出数据
        output_frame = ttk.LabelFrame(parent, text="输出结果", padding="5")
        output_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.triple_output_text = tk.Text(output_frame, height=6, width=60)
        self.triple_output_text.grid(row=0, column=0, columnspan=2, pady=5)

    def setup_attack_ui(self, parent):
        # 明密文对输入
        pair_frame = ttk.LabelFrame(parent, text="明密文对", padding="5")
        pair_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(pair_frame, text="明文:").grid(row=0, column=0, sticky=tk.W)
        self.attack_plain_text = tk.Text(pair_frame, height=3, width=60)
        self.attack_plain_text.grid(row=1, column=0, columnspan=2, pady=5)
        self.attack_plain_text.insert("1.0", "Hello")

        ttk.Label(pair_frame, text="密文:").grid(row=2, column=0, sticky=tk.W)
        self.attack_cipher_text = tk.Text(pair_frame, height=3, width=60)
        self.attack_cipher_text.grid(row=3, column=0, columnspan=2, pady=5)

        # 添加第二对明密文
        ttk.Label(pair_frame, text="第二明文 (可选):").grid(row=4, column=0, sticky=tk.W)
        self.attack_plain2_text = tk.Text(pair_frame, height=3, width=60)
        self.attack_plain2_text.grid(row=5, column=0, columnspan=2, pady=5)

        ttk.Label(pair_frame, text="第二密文 (可选):").grid(row=6, column=0, sticky=tk.W)
        self.attack_cipher2_text = tk.Text(pair_frame, height=3, width=60)
        self.attack_cipher2_text.grid(row=7, column=0, columnspan=2, pady=5)

        # 攻击按钮
        attack_button_frame = ttk.Frame(parent)
        attack_button_frame.grid(row=1, column=0, columnspan=2, pady=10)

        ttk.Button(attack_button_frame, text="执行中间相遇攻击",
                   command=self.perform_attack).grid(row=0, column=0, padx=5)
        ttk.Button(attack_button_frame, text="清空",
                   command=self.attack_clear).grid(row=0, column=1, padx=5)

        # 输出结果
        output_frame = ttk.LabelFrame(parent, text="攻击结果", padding="5")
        output_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        self.attack_output_text = tk.Text(output_frame, height=8, width=60)
        self.attack_output_text.grid(row=0, column=0, columnspan=2, pady=5)

        # 状态信息
        self.attack_status_var = tk.StringVar()
        self.attack_status_bar = ttk.Label(parent, textvariable=self.attack_status_var, relief=tk.SUNKEN)
        self.attack_status_bar.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        self.attack_status_var.set("就绪")

    # 单重加密相关方法
    def on_single_type_change(self):
        if self.single_input_type.get() == "binary":
            self.single_input_label.config(text="16位数据:")
            self.single_input_text.delete("1.0", tk.END)
            self.single_input_text.insert("1.0", "0110111101101011")
        else:
            self.single_input_label.config(text="ASCII文本:")
            self.single_input_text.delete("1.0", tk.END)
            self.single_input_text.insert("1.0", "Hello World!")

    def single_encrypt(self):
        try:
            key_str = self.single_key_entry.get().strip()
            if not self.validate_binary(key_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key = int(key_str, 2)
            input_data = self.single_input_text.get("1.0", tk.END).strip()

            if self.single_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                plaintext = int(input_data, 2)
                ciphertext = self.saes.encrypt_block(plaintext, key)
                output_bin = format(ciphertext, '016b')
                self.single_output_text.delete("1.0", tk.END)
                self.single_output_text.insert("1.0", f"密文(二进制): {output_bin}\n")
                self.single_output_text.insert(tk.END, f"密文(十六进制): {format(ciphertext, '04X')}")

            else:
                ciphertext = self.saes.encrypt_text(input_data, key)
                self.single_output_text.delete("1.0", tk.END)
                self.single_output_text.insert("1.0", f"密文: {ciphertext}\n")
                hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
                self.single_output_text.insert(tk.END, f"十六进制: {hex_representation}")

        except Exception as e:
            messagebox.showerror("错误", f"加密过程中发生错误: {str(e)}")

    def single_decrypt(self):
        try:
            key_str = self.single_key_entry.get().strip()
            if not self.validate_binary(key_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key = int(key_str, 2)
            input_data = self.single_input_text.get("1.0", tk.END).strip()

            if self.single_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                ciphertext = int(input_data, 2)
                plaintext = self.saes.decrypt_block(ciphertext, key)
                output_bin = format(plaintext, '016b')
                self.single_output_text.delete("1.0", tk.END)
                self.single_output_text.insert("1.0", f"明文(二进制): {output_bin}\n")

                char1 = chr((plaintext >> 8) & 0xFF)
                char2 = chr(plaintext & 0xFF)
                if char1.isprintable() and char2.isprintable():
                    self.single_output_text.insert(tk.END, f"ASCII字符: '{char1}{char2}'")
                else:
                    self.single_output_text.insert(tk.END, "无法显示为可打印ASCII字符")

            else:
                plaintext = self.saes.decrypt_text(input_data, key)
                self.single_output_text.delete("1.0", tk.END)
                self.single_output_text.insert("1.0", f"明文: {plaintext}")

        except Exception as e:
            messagebox.showerror("错误", f"解密过程中发生错误: {str(e)}")

    def single_clear(self):
        self.single_input_text.delete("1.0", tk.END)
        self.single_output_text.delete("1.0", tk.END)

    # 双重加密相关方法
    def on_double_type_change(self):
        if self.double_input_type.get() == "binary":
            self.double_input_label.config(text="16位数据:")
            self.double_input_text.delete("1.0", tk.END)
            self.double_input_text.insert("1.0", "0110111101101011")
        else:
            self.double_input_label.config(text="ASCII文本:")
            self.double_input_text.delete("1.0", tk.END)
            self.double_input_text.insert("1.0", "Hello World!")

    def double_encrypt(self):
        try:
            key1_str = self.double_key1_entry.get().strip()
            key2_str = self.double_key2_entry.get().strip()

            if not self.validate_binary(key1_str, 16) or not self.validate_binary(key2_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key1 = int(key1_str, 2)
            key2 = int(key2_str, 2)
            input_data = self.double_input_text.get("1.0", tk.END).strip()

            if self.double_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                plaintext = int(input_data, 2)
                ciphertext = self.saes.double_encrypt_block(plaintext, key1, key2)
                output_bin = format(ciphertext, '016b')
                self.double_output_text.delete("1.0", tk.END)
                self.double_output_text.insert("1.0", f"密文(二进制): {output_bin}\n")
                self.double_output_text.insert(tk.END, f"密文(十六进制): {format(ciphertext, '04X')}")

            else:
                ciphertext = self.saes.double_encrypt_text(input_data, key1, key2)
                self.double_output_text.delete("1.0", tk.END)
                self.double_output_text.insert("1.0", f"密文: {ciphertext}\n")
                hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
                self.double_output_text.insert(tk.END, f"十六进制: {hex_representation}")

        except Exception as e:
            messagebox.showerror("错误", f"加密过程中发生错误: {str(e)}")

    def double_decrypt(self):
        try:
            key1_str = self.double_key1_entry.get().strip()
            key2_str = self.double_key2_entry.get().strip()

            if not self.validate_binary(key1_str, 16) or not self.validate_binary(key2_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            key1 = int(key1_str, 2)
            key2 = int(key2_str, 2)
            input_data = self.double_input_text.get("1.0", tk.END).strip()

            if self.double_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                ciphertext = int(input_data, 2)
                plaintext = self.saes.double_decrypt_block(ciphertext, key1, key2)
                output_bin = format(plaintext, '016b')
                self.double_output_text.delete("1.0", tk.END)
                self.double_output_text.insert("1.0", f"明文(二进制): {output_bin}\n")

                char1 = chr((plaintext >> 8) & 0xFF)
                char2 = chr(plaintext & 0xFF)
                if char1.isprintable() and char2.isprintable():
                    self.double_output_text.insert(tk.END, f"ASCII字符: '{char1}{char2}'")
                else:
                    self.double_output_text.insert(tk.END, "无法显示为可打印ASCII字符")

            else:
                plaintext = self.saes.double_decrypt_text(input_data, key1, key2)
                self.double_output_text.delete("1.0", tk.END)
                self.double_output_text.insert("1.0", f"明文: {plaintext}")

        except Exception as e:
            messagebox.showerror("错误", f"解密过程中发生错误: {str(e)}")

    def double_clear(self):
        self.double_input_text.delete("1.0", tk.END)
        self.double_output_text.delete("1.0", tk.END)

    # 三重加密相关方法
    def on_triple_type_change(self):
        if self.triple_input_type.get() == "binary":
            self.triple_input_label.config(text="16位数据:")
            self.triple_input_text.delete("1.0", tk.END)
            self.triple_input_text.insert("1.0", "0110111101101011")
        else:
            self.triple_input_label.config(text="ASCII文本:")
            self.triple_input_text.delete("1.0", tk.END)
            self.triple_input_text.insert("1.0", "Hello World!")

    def triple_encrypt(self):
        try:
            key1_str = self.triple_key1_entry.get().strip()
            key2_str = self.triple_key2_entry.get().strip()
            key3_str = self.triple_key3_entry.get().strip()

            if not (self.validate_binary(key1_str, 16) and
                    self.validate_binary(key2_str, 16) and
                    self.validate_binary(key3_str, 16)):
                messagebox.showerror("错误", "所有密钥必须是16位二进制数")
                return

            key1 = int(key1_str, 2)
            key2 = int(key2_str, 2)
            key3 = int(key3_str, 2)
            input_data = self.triple_input_text.get("1.0", tk.END).strip()

            if self.triple_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                plaintext = int(input_data, 2)
                ciphertext = self.saes.triple_encrypt_block(plaintext, key1, key2, key3)
                output_bin = format(ciphertext, '016b')
                self.triple_output_text.delete("1.0", tk.END)
                self.triple_output_text.insert("1.0", f"密文(二进制): {output_bin}\n")
                self.triple_output_text.insert(tk.END, f"密文(十六进制): {format(ciphertext, '04X')}")

            else:
                ciphertext = self.saes.triple_encrypt_text(input_data, key1, key2, key3)
                self.triple_output_text.delete("1.0", tk.END)
                self.triple_output_text.insert("1.0", f"密文: {ciphertext}\n")
                hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
                self.triple_output_text.insert(tk.END, f"十六进制: {hex_representation}")

        except Exception as e:
            messagebox.showerror("错误", f"加密过程中发生错误: {str(e)}")

    def triple_decrypt(self):
        try:
            key1_str = self.triple_key1_entry.get().strip()
            key2_str = self.triple_key2_entry.get().strip()
            key3_str = self.triple_key3_entry.get().strip()

            if not (self.validate_binary(key1_str, 16) and
                    self.validate_binary(key2_str, 16) and
                    self.validate_binary(key3_str, 16)):
                messagebox.showerror("错误", "所有密钥必须是16位二进制数")
                return

            key1 = int(key1_str, 2)
            key2 = int(key2_str, 2)
            key3 = int(key3_str, 2)
            input_data = self.triple_input_text.get("1.0", tk.END).strip()

            if self.triple_input_type.get() == "binary":
                if not self.validate_binary(input_data, 16):
                    messagebox.showerror("错误", "输入数据必须是16位二进制数")
                    return

                ciphertext = int(input_data, 2)
                plaintext = self.saes.triple_decrypt_block(ciphertext, key1, key2, key3)
                output_bin = format(plaintext, '016b')
                self.triple_output_text.delete("1.0", tk.END)
                self.triple_output_text.insert("1.0", f"明文(二进制): {output_bin}\n")

                char1 = chr((plaintext >> 8) & 0xFF)
                char2 = chr(plaintext & 0xFF)
                if char1.isprintable() and char2.isprintable():
                    self.triple_output_text.insert(tk.END, f"ASCII字符: '{char1}{char2}'")
                else:
                    self.triple_output_text.insert(tk.END, "无法显示为可打印ASCII字符")

            else:
                plaintext = self.saes.triple_decrypt_text(input_data, key1, key2, key3)
                self.triple_output_text.delete("1.0", tk.END)
                self.triple_output_text.insert("1.0", f"明文: {plaintext}")

        except Exception as e:
            messagebox.showerror("错误", f"解密过程中发生错误: {str(e)}")

    def triple_clear(self):
        self.triple_input_text.delete("1.0", tk.END)
        self.triple_output_text.delete("1.0", tk.END)

    # 中间相遇攻击相关方法
    def perform_attack(self):
        try:
            self.attack_status_var.set("正在执行中间相遇攻击，请稍候...")
            self.root.update()

            # 获取第一对明密文
            plaintext1 = self.attack_plain_text.get("1.0", tk.END).strip()
            ciphertext1 = self.attack_cipher_text.get("1.0", tk.END).strip()

            if not plaintext1 or not ciphertext1:
                messagebox.showerror("错误", "至少需要一对明密文")
                return

            plaintexts = [plaintext1]
            ciphertexts = [ciphertext1]

            # 获取第二对明密文（如果存在）
            plaintext2 = self.attack_plain2_text.get("1.0", tk.END).strip()
            ciphertext2 = self.attack_cipher2_text.get("1.0", tk.END).strip()

            if plaintext2 and ciphertext2:
                plaintexts.append(plaintext2)
                ciphertexts.append(ciphertext2)

            # 执行攻击
            possible_keys = self.mitm_attack.attack(plaintexts, ciphertexts, max_keys=10)

            # 显示结果
            self.attack_output_text.delete("1.0", tk.END)

            if possible_keys:
                self.attack_output_text.insert("1.0", f"找到 {len(possible_keys)} 个可能的密钥对:\n\n")

                for i, (k1, k2) in enumerate(possible_keys, 1):
                    k1_bin = format(k1, '016b')
                    k2_bin = format(k2, '016b')
                    total_key = k1_bin + k2_bin

                    self.attack_output_text.insert(tk.END,
                                                   f"密钥对 {i}:\n"
                                                   f"  K1: {k1_bin} ({format(k1, '04X')}H)\n"
                                                   f"  K2: {k2_bin} ({format(k2, '04X')}H)\n"
                                                   f"  完整密钥: {total_key}\n\n")

                # 验证第一个密钥对
                k1, k2 = possible_keys[0]
                test_plain = plaintexts[0]
                expected_cipher = ciphertexts[0]

                actual_cipher = self.saes.double_encrypt_text(test_plain, k1, k2)

                self.attack_output_text.insert(tk.END,
                                               f"验证第一个密钥对:\n"
                                               f"  明文: {test_plain}\n"
                                               f"  预期密文: {expected_cipher}\n"
                                               f"  实际密文: {actual_cipher}\n"
                                               f"  匹配: {'是' if actual_cipher == expected_cipher else '否'}")

                self.attack_status_var.set(f"攻击完成，找到 {len(possible_keys)} 个可能的密钥对")
            else:
                self.attack_output_text.insert("1.0", "未找到可能的密钥对")
                self.attack_status_var.set("攻击完成，未找到可能的密钥对")

        except Exception as e:
            messagebox.showerror("错误", f"攻击过程中发生错误: {str(e)}")
            self.attack_status_var.set("攻击失败")

    def attack_clear(self):
        self.attack_plain_text.delete("1.0", tk.END)
        self.attack_cipher_text.delete("1.0", tk.END)
        self.attack_plain2_text.delete("1.0", tk.END)
        self.attack_cipher2_text.delete("1.0", tk.END)
        self.attack_output_text.delete("1.0", tk.END)
        self.attack_status_var.set("已清空")

    # 通用验证方法
    def validate_binary(self, text, length):
        """验证二进制输入"""
        if len(text) != length:
            return False
        for char in text:
            if char not in '01':
                return False
        return True


def main():
    root = tk.Tk()
    app = SAESGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()