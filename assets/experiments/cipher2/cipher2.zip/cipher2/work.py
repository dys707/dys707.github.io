import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import os
import random


class SAES:
    def __init__(self):
        # S盒和逆S盒
        self.S_BOX = [
            [0x9, 0x4, 0xA, 0xB],
            [0xD, 0x1, 0x8, 0x5],
            [0x6, 0x2, 0x0, 0x3],
            [0xC, 0xE, 0xF, 0x7]
        ]

        self.INV_S_BOX = [
            [0xA, 0x5, 0x9, 0xB],
            [0x1, 0x7, 0x8, 0xF],
            [0x6, 0x0, 0x2, 0x3],
            [0xC, 0x4, 0xD, 0xE]
        ]

        # 轮常数
        self.RCON = [0x80, 0x30]

    def gf_mult(self, a, b):
        """在GF(2^4)上的乘法"""
        result = 0
        for _ in range(4):
            if b & 1:
                result ^= a
            hi_bit_set = a & 0x8
            a <<= 1
            a &= 0xF
            if hi_bit_set:
                a ^= 0x3
            b >>= 1
        return result

    def sub_nibbles(self, state, inverse=False):
        """半字节替换"""
        s_box = self.INV_S_BOX if inverse else self.S_BOX
        result = []
        for nibble in state:
            row = (nibble >> 2) & 0x3
            col = nibble & 0x3
            result.append(s_box[row][col])
        return result

    def shift_rows(self, state):
        """行移位"""
        return [state[0], state[1], state[3], state[2]]

    def mix_columns(self, state, inverse=False):
        """列混淆"""
        result = [0] * 4
        if inverse:
            # 逆列混淆矩阵
            result[0] = self.gf_mult(0x9, state[0]) ^ self.gf_mult(0x2, state[2])
            result[1] = self.gf_mult(0x9, state[1]) ^ self.gf_mult(0x2, state[3])
            result[2] = self.gf_mult(0x2, state[0]) ^ self.gf_mult(0x9, state[2])
            result[3] = self.gf_mult(0x2, state[1]) ^ self.gf_mult(0x9, state[3])
        else:
            # 列混淆矩阵
            result[0] = state[0] ^ self.gf_mult(0x4, state[2])
            result[1] = state[1] ^ self.gf_mult(0x4, state[3])
            result[2] = self.gf_mult(0x4, state[0]) ^ state[2]
            result[3] = self.gf_mult(0x4, state[1]) ^ state[3]
        return result

    def key_expansion(self, key):
        """密钥扩展"""
        # 将16位密钥分成4个半字节
        w = [(key >> 12) & 0xF, (key >> 8) & 0xF,
             (key >> 4) & 0xF, key & 0xF]

        # 生成扩展密钥
        w.append(w[0] ^ self.RCON[0] ^ self.S_BOX[(w[3] >> 2) & 0x3][w[3] & 0x3])
        w.append(w[1] ^ w[4])
        w.append(w[2] ^ w[5])
        w.append(w[3] ^ w[6])

        w.append(w[4] ^ self.RCON[1] ^ self.S_BOX[(w[7] >> 2) & 0x3][w[7] & 0x3])
        w.append(w[5] ^ w[8])
        w.append(w[6] ^ w[9])
        w.append(w[7] ^ w[10])

        # 组织成轮密钥
        k0 = (w[0] << 12) | (w[1] << 8) | (w[2] << 4) | w[3]
        k1 = (w[4] << 12) | (w[5] << 8) | (w[6] << 4) | w[7]
        k2 = (w[8] << 12) | (w[9] << 8) | (w[10] << 4) | w[11]

        return k0, k1, k2

    def add_round_key(self, state, key):
        """轮密钥加"""
        key_nibbles = [(key >> 12) & 0xF, (key >> 8) & 0xF,
                       (key >> 4) & 0xF, key & 0xF]
        return [state[i] ^ key_nibbles[i] for i in range(4)]

    def encrypt_block(self, plaintext, key):
        """加密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位明文分成4个半字节
        state = [(plaintext >> 12) & 0xF, (plaintext >> 8) & 0xF,
                 (plaintext >> 4) & 0xF, plaintext & 0xF]

        # 第0轮轮密钥加
        state = self.add_round_key(state, k0)

        # 第1轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.mix_columns(state)
        state = self.add_round_key(state, k1)

        # 第2轮
        state = self.sub_nibbles(state)
        state = self.shift_rows(state)
        state = self.add_round_key(state, k2)

        # 组合成16位密文
        ciphertext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return ciphertext

    def decrypt_block(self, ciphertext, key):
        """解密一个16位数据块"""
        k0, k1, k2 = self.key_expansion(key)

        # 将16位密文分成4个半字节
        state = [(ciphertext >> 12) & 0xF, (ciphertext >> 8) & 0xF,
                 (ciphertext >> 4) & 0xF, ciphertext & 0xF]

        # 逆向第2轮
        state = self.add_round_key(state, k2)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第1轮
        state = self.add_round_key(state, k1)
        state = self.mix_columns(state, inverse=True)
        state = self.shift_rows(state)
        state = self.sub_nibbles(state, inverse=True)

        # 逆向第0轮
        state = self.add_round_key(state, k0)

        # 组合成16位明文
        plaintext = (state[0] << 12) | (state[1] << 8) | (state[2] << 4) | state[3]
        return plaintext

    def generate_iv(self):
        """生成16位随机初始向量"""
        return random.randint(0, 65535)

    def cbc_encrypt(self, plaintext_blocks, key, iv):
        """CBC模式加密"""
        ciphertext_blocks = []
        previous_block = iv

        for block in plaintext_blocks:
            # 明文块与前一个密文块异或
            xored_block = block ^ previous_block
            # 加密
            encrypted_block = self.encrypt_block(xored_block, key)
            ciphertext_blocks.append(encrypted_block)
            previous_block = encrypted_block

        return ciphertext_blocks

    def cbc_decrypt(self, ciphertext_blocks, key, iv):
        """CBC模式解密"""
        plaintext_blocks = []
        previous_block = iv

        for block in ciphertext_blocks:
            # 解密
            decrypted_block = self.decrypt_block(block, key)
            # 与前一个密文块异或得到明文
            plaintext_block = decrypted_block ^ previous_block
            plaintext_blocks.append(plaintext_block)
            previous_block = block

        return plaintext_blocks

    def text_to_blocks(self, text):
        """将文本转换为16位数据块列表"""
        blocks = []
        # 确保文本长度为偶数
        if len(text) % 2 != 0:
            text += ' '  # 填充空格

        for i in range(0, len(text), 2):
            block = (ord(text[i]) << 8) | ord(text[i + 1])
            blocks.append(block)

        return blocks

    def blocks_to_text(self, blocks):
        """将16位数据块列表转换为文本"""
        text = ""
        for block in blocks:
            char1 = (block >> 8) & 0xFF
            char2 = block & 0xFF
            # 只添加可打印字符，否则用占位符
            if 32 <= char1 <= 126:
                text += chr(char1)
            else:
                text += '?'
            if 32 <= char2 <= 126:
                text += chr(char2)
            else:
                text += '?'
        return text

    def encrypt_text_cbc(self, plaintext, key, iv):
        """使用CBC模式加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = self.cbc_encrypt(blocks, key, iv)
        return cipher_blocks, self.blocks_to_text(cipher_blocks)

    def decrypt_text_cbc(self, cipher_blocks, key, iv):
        """使用CBC模式解密密文块"""
        plain_blocks = self.cbc_decrypt(cipher_blocks, key, iv)
        return self.blocks_to_text(plain_blocks)

    def modify_cipher_block(self, cipher_blocks, index, modification):
        """
        修改指定的密文块
        cipher_blocks: 密文块列表
        index: 要修改的块索引
        modification: 修改方式，可以是:
          - 'flip': 随机翻转一些位
          - 'replace': 替换为指定值
          - value: 直接指定新值
        """
        modified_blocks = cipher_blocks.copy()

        if index < 0 or index >= len(modified_blocks):
            raise ValueError("索引超出范围")

        if modification == 'flip':
            # 随机翻转1-4位
            flip_positions = random.sample(range(16), random.randint(1, 4))
            new_block = modified_blocks[index]
            for pos in flip_positions:
                new_block ^= (1 << pos)
            modified_blocks[index] = new_block
        elif modification == 'replace':
            # 替换为随机值
            modified_blocks[index] = random.randint(0, 65535)
        elif isinstance(modification, int):
            # 直接指定新值
            modified_blocks[index] = modification
        else:
            raise ValueError("不支持的修改类型")

        return modified_blocks


class SAESCBCGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("S-AES CBC模式加密解密")
        self.root.geometry("800x700")

        self.saes = SAES()
        self.current_cipher_blocks = []
        self.current_iv = 0
        self.current_key = 0

        self.setup_ui()

    def setup_ui(self):
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill='both', expand=True)

        # 密钥和IV输入
        key_iv_frame = ttk.LabelFrame(main_frame, text="密钥和初始向量", padding="5")
        key_iv_frame.pack(fill='x', pady=5)

        ttk.Label(key_iv_frame, text="16位密钥:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.key_entry = ttk.Entry(key_iv_frame, width=20)
        self.key_entry.grid(row=0, column=1, padx=5)
        self.key_entry.insert(0, "1010111100110001")

        ttk.Label(key_iv_frame, text="16位IV:").grid(row=1, column=0, sticky=tk.W, padx=5)
        self.iv_entry = ttk.Entry(key_iv_frame, width=20)
        self.iv_entry.grid(row=1, column=1, padx=5)

        ttk.Button(key_iv_frame, text="生成随机IV",
                   command=self.generate_random_iv).grid(row=1, column=2, padx=5)

        # 输入数据
        input_frame = ttk.LabelFrame(main_frame, text="输入数据", padding="5")
        input_frame.pack(fill='x', pady=5)

        self.input_text = tk.Text(input_frame, height=6, width=80)
        self.input_text.pack(pady=5)
        self.input_text.insert("1.0", "Hello World! This is a test message for CBC mode.")

        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', pady=10)

        ttk.Button(button_frame, text="CBC加密", command=self.cbc_encrypt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="CBC解密", command=self.cbc_decrypt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="清空", command=self.clear).pack(side=tk.LEFT, padx=5)

        # 输出数据
        output_frame = ttk.LabelFrame(main_frame, text="输出结果", padding="5")
        output_frame.pack(fill='both', expand=True, pady=5)

        self.output_text = tk.Text(output_frame, height=8, width=80)
        self.output_text.pack(fill='both', expand=True, pady=5)

        # 篡改操作框架
        tamper_frame = ttk.LabelFrame(main_frame, text="密文篡改实验", padding="5")
        tamper_frame.pack(fill='x', pady=5)

        tamper_inner_frame = ttk.Frame(tamper_frame)
        tamper_inner_frame.pack(fill='x')

        ttk.Label(tamper_inner_frame, text="篡改块索引:").grid(row=0, column=0, padx=5)
        self.tamper_index_entry = ttk.Entry(tamper_inner_frame, width=5)
        self.tamper_index_entry.grid(row=0, column=1, padx=5)
        self.tamper_index_entry.insert(0, "1")

        ttk.Label(tamper_inner_frame, text="篡改方式:").grid(row=0, column=2, padx=5)
        self.tamper_method = ttk.Combobox(tamper_inner_frame,
                                          values=["随机位翻转", "替换为随机值", "指定值"],
                                          state="readonly", width=15)
        self.tamper_method.grid(row=0, column=3, padx=5)
        self.tamper_method.set("随机位翻转")

        ttk.Label(tamper_inner_frame, text="指定值(16位):").grid(row=0, column=4, padx=5)
        self.specific_value_entry = ttk.Entry(tamper_inner_frame, width=20)
        self.specific_value_entry.grid(row=0, column=5, padx=5)
        self.specific_value_entry.insert(0, "1111111111111111")

        ttk.Button(tamper_inner_frame, text="篡改密文并解密",
                   command=self.tamper_and_decrypt).grid(row=0, column=6, padx=5)

        # 状态栏
        self.status_var = tk.StringVar()
        self.status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        self.status_bar.pack(fill='x', pady=5)

        self.status_var.set("就绪")

        # 生成初始IV
        self.generate_random_iv()

    def generate_random_iv(self):
        """生成随机IV并显示在输入框中"""
        iv = self.saes.generate_iv()
        iv_bin = format(iv, '016b')
        self.iv_entry.delete(0, tk.END)
        self.iv_entry.insert(0, iv_bin)
        self.status_var.set(f"已生成随机IV: {iv_bin}")

    def validate_binary(self, text, length):
        """验证二进制输入"""
        if len(text) != length:
            return False
        for char in text:
            if char not in '01':
                return False
        return True

    def cbc_encrypt(self):
        """执行CBC加密"""
        try:
            key_str = self.key_entry.get().strip()
            iv_str = self.iv_entry.get().strip()

            if not self.validate_binary(key_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            if not self.validate_binary(iv_str, 16):
                messagebox.showerror("错误", "IV必须是16位二进制数")
                return

            key = int(key_str, 2)
            iv = int(iv_str, 2)
            plaintext = self.input_text.get("1.0", tk.END).strip()

            # 保存当前密钥和IV
            self.current_key = key
            self.current_iv = iv

            # 执行加密
            cipher_blocks, cipher_text = self.saes.encrypt_text_cbc(plaintext, key, iv)
            self.current_cipher_blocks = cipher_blocks

            # 显示结果
            self.output_text.delete("1.0", tk.END)
            self.output_text.insert("1.0", "CBC加密结果:\n\n")
            self.output_text.insert(tk.END, f"明文: {plaintext}\n\n")
            self.output_text.insert(tk.END, f"密文(ASCII): {cipher_text}\n\n")

            # 显示每个块的详细信息
            self.output_text.insert(tk.END, "密文块详情:\n")
            for i, block in enumerate(cipher_blocks):
                block_bin = format(block, '016b')
                block_hex = format(block, '04X')
                self.output_text.insert(tk.END, f"  块{i}: {block_bin} ({block_hex}H)\n")

            self.status_var.set("CBC加密完成")

        except Exception as e:
            messagebox.showerror("错误", f"加密过程中发生错误: {str(e)}")

    def cbc_decrypt(self):
        """执行CBC解密"""
        try:
            if not self.current_cipher_blocks:
                messagebox.showerror("错误", "请先进行加密操作")
                return

            key_str = self.key_entry.get().strip()
            iv_str = self.iv_entry.get().strip()

            if not self.validate_binary(key_str, 16):
                messagebox.showerror("错误", "密钥必须是16位二进制数")
                return

            if not self.validate_binary(iv_str, 16):
                messagebox.showerror("错误", "IV必须是16位二进制数")
                return

            key = int(key_str, 2)
            iv = int(iv_str, 2)

            # 执行解密
            plaintext = self.saes.decrypt_text_cbc(self.current_cipher_blocks, key, iv)

            # 显示结果
            self.output_text.delete("1.0", tk.END)
            self.output_text.insert("1.0", "CBC解密结果:\n\n")
            self.output_text.insert(tk.END, f"解密文本: {plaintext}\n\n")

            # 显示原始密文块
            self.output_text.insert(tk.END, "原始密文块:\n")
            for i, block in enumerate(self.current_cipher_blocks):
                block_bin = format(block, '016b')
                block_hex = format(block, '04X')
                self.output_text.insert(tk.END, f"  块{i}: {block_bin} ({block_hex}H)\n")

            self.status_var.set("CBC解密完成")

        except Exception as e:
            messagebox.showerror("错误", f"解密过程中发生错误: {str(e)}")

    def tamper_and_decrypt(self):
        """篡改密文并解密，展示CBC模式的错误传播特性"""
        try:
            if not self.current_cipher_blocks:
                messagebox.showerror("错误", "请先进行加密操作")
                return

            # 获取篡改参数
            index_str = self.tamper_index_entry.get().strip()
            method = self.tamper_method.get()

            if not index_str.isdigit():
                messagebox.showerror("错误", "索引必须是数字")
                return

            index = int(index_str)
            if index < 0 or index >= len(self.current_cipher_blocks):
                messagebox.showerror("错误", f"索引必须在0到{len(self.current_cipher_blocks) - 1}之间")
                return

            # 确定修改方式
            if method == "随机位翻转":
                modification = 'flip'
            elif method == "替换为随机值":
                modification = 'replace'
            elif method == "指定值":
                value_str = self.specific_value_entry.get().strip()
                if not self.validate_binary(value_str, 16):
                    messagebox.showerror("错误", "指定值必须是16位二进制数")
                    return
                modification = int(value_str, 2)
            else:
                messagebox.showerror("错误", "请选择有效的篡改方式")
                return

            # 执行篡改
            modified_blocks = self.saes.modify_cipher_block(
                self.current_cipher_blocks, index, modification)

            # 解密篡改后的密文
            plaintext = self.saes.decrypt_text_cbc(modified_blocks, self.current_key, self.current_iv)

            # 显示对比结果
            self.output_text.delete("1.0", tk.END)
            self.output_text.insert("1.0", "密文篡改实验 - CBC模式错误传播分析:\n\n")

            # 显示篡改信息
            self.output_text.insert(tk.END, f"篡改的块索引: {index}\n")
            self.output_text.insert(tk.END, f"篡改方式: {method}\n\n")

            # 显示篡改前后的密文块
            self.output_text.insert(tk.END, "篡改前的密文块:\n")
            for i, block in enumerate(self.current_cipher_blocks):
                marker = " <-- 被篡改" if i == index else ""
                block_bin = format(block, '016b')
                self.output_text.insert(tk.END, f"  块{i}: {block_bin}{marker}\n")

            self.output_text.insert(tk.END, "\n篡改后的密文块:\n")
            for i, block in enumerate(modified_blocks):
                marker = " <-- 已篡改" if i == index else ""
                block_bin = format(block, '016b')
                self.output_text.insert(tk.END, f"  块{i}: {block_bin}{marker}\n")

            # 显示解密结果
            original_plaintext = self.saes.decrypt_text_cbc(
                self.current_cipher_blocks, self.current_key, self.current_iv)

            self.output_text.insert(tk.END, f"\n原始解密结果: {original_plaintext}\n")
            self.output_text.insert(tk.END, f"篡改后解密结果: {plaintext}\n\n")

            # 分析错误传播
            self.output_text.insert(tk.END, "错误传播分析:\n")
            self.output_text.insert(tk.END, f"  - 块{index}: 完全损坏 (对应篡改的密文块)\n")
            if index + 1 < len(modified_blocks):
                self.output_text.insert(tk.END, f"  - 块{index + 1}: 部分损坏 (因CBC模式链式依赖)\n")
            if index + 2 < len(modified_blocks):
                self.output_text.insert(tk.END, f"  - 块{index + 2}+: 未受影响\n")

            self.status_var.set("篡改实验完成")

        except Exception as e:
            messagebox.showerror("错误", f"篡改实验过程中发生错误: {str(e)}")

    def clear(self):
        """清空输入输出"""
        self.input_text.delete("1.0", tk.END)
        self.output_text.delete("1.0", tk.END)
        self.current_cipher_blocks = []
        self.status_var.set("已清空")


def main():
    root = tk.Tk()
    app = SAESCBCGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()