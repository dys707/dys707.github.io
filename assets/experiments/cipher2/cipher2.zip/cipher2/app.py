from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import random
import sys
import os
from S_AES_3 import MeetInTheMiddleAttack
# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)
CORS(app)

# 直接从S_AES.py导入SAES类
from S_AES import SAES

# 创建SAES实例
saes = SAES()
# 创建中间相遇攻击实例
mitm_attack = MeetInTheMiddleAttack(saes)
def validate_binary(text, length):
    """验证二进制输入"""
    if len(text) != length:
        return False
    for char in text:
        if char not in '01':
            return False
    return True

# 根路由 - 返回HTML页面
@app.route('/')
def index():
    return render_template('index.html')

# 基础加解密API
@app.route('/api/basic/encrypt', methods=['POST'])
def basic_encrypt():
    try:
        data = request.json
        key_str = data.get('key', '')
        input_data = data.get('input', '')
        input_type = data.get('type', 'binary')
        
        if not validate_binary(key_str, 16):
            return jsonify({'error': '密钥必须是16位二进制数'}), 400
        
        key = int(key_str, 2)
        
        if input_type == 'binary':
            if not validate_binary(input_data, 16):
                return jsonify({'error': '输入数据必须是16位二进制数'}), 400
            plaintext = int(input_data, 2)
            ciphertext = saes.encrypt_block(plaintext, key)
            result = {
                'binary': format(ciphertext, '016b'),
                'hex': format(ciphertext, '04X')
            }
        else:
            ciphertext = saes.encrypt_text(input_data, key)
            hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
            result = {
                'text': ciphertext,
                'hex': hex_representation
            }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/basic/decrypt', methods=['POST'])
def basic_decrypt():
    try:
        data = request.json
        key_str = data.get('key', '')
        input_data = data.get('input', '')
        input_type = data.get('type', 'binary')
        
        if not validate_binary(key_str, 16):
            return jsonify({'error': '密钥必须是16位二进制数'}), 400
        
        key = int(key_str, 2)
        
        if input_type == 'binary':
            if not validate_binary(input_data, 16):
                return jsonify({'error': '输入数据必须是16位二进制数'}), 400
            ciphertext = int(input_data, 2)
            plaintext = saes.decrypt_block(ciphertext, key)
            result = {
                'binary': format(plaintext, '016b'),
                'ascii': chr((plaintext >> 8) & 0xFF) + chr(plaintext & 0xFF)
            }
        else:
            plaintext = saes.decrypt_text(input_data, key)
            result = {
                'text': plaintext
            }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 多重加密API - 添加缺失的方法到SAES类
def add_missing_methods():
    """为SAES类添加缺失的多重加密方法"""
    
    def double_encrypt_block(self, plaintext, key1, key2):
        """双重加密: E(K2, E(K1, P))"""
        intermediate = self.encrypt_block(plaintext, key1)
        return self.encrypt_block(intermediate, key2)
    
    def double_decrypt_block(self, ciphertext, key1, key2):
        """双重解密: D(K1, D(K2, C))"""
        intermediate = self.decrypt_block(ciphertext, key2)
        return self.decrypt_block(intermediate, key1)
    
    def triple_encrypt_block(self, plaintext, key1, key2, key3):
        """三重加密: E(K3, D(K2, E(K1, P)))"""
        step1 = self.encrypt_block(plaintext, key1)
        step2 = self.decrypt_block(step1, key2)
        return self.encrypt_block(step2, key3)
    
    def triple_decrypt_block(self, ciphertext, key1, key2, key3):
        """三重解密: D(K1, E(K2, D(K3, C)))"""
        step1 = self.decrypt_block(ciphertext, key3)
        step2 = self.encrypt_block(step1, key2)
        return self.decrypt_block(step2, key1)
    
    def double_encrypt_text(self, plaintext, key1, key2):
        """双重加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.double_encrypt_block(block, key1, key2) for block in blocks]
        return self.blocks_to_text(cipher_blocks)
    
    def double_decrypt_text(self, ciphertext, key1, key2):
        """双重解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.double_decrypt_block(block, key1, key2) for block in blocks]
        return self.blocks_to_text(plain_blocks)
    
    def triple_encrypt_text(self, plaintext, key1, key2, key3):
        """三重加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = [self.triple_encrypt_block(block, key1, key2, key3) for block in blocks]
        return self.blocks_to_text(cipher_blocks)
    
    def triple_decrypt_text(self, ciphertext, key1, key2, key3):
        """三重解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = [self.triple_decrypt_block(block, key1, key2, key3) for block in blocks]
        return self.blocks_to_text(plain_blocks)
    
    # 将这些方法添加到SAES类
    saes.double_encrypt_block = double_encrypt_block.__get__(saes, SAES)
    saes.double_decrypt_block = double_decrypt_block.__get__(saes, SAES)
    saes.triple_encrypt_block = triple_encrypt_block.__get__(saes, SAES)
    saes.triple_decrypt_block = triple_decrypt_block.__get__(saes, SAES)
    saes.double_encrypt_text = double_encrypt_text.__get__(saes, SAES)
    saes.double_decrypt_text = double_decrypt_text.__get__(saes, SAES)
    saes.triple_encrypt_text = triple_encrypt_text.__get__(saes, SAES)
    saes.triple_decrypt_text = triple_decrypt_text.__get__(saes, SAES)

# 添加缺失的方法
add_missing_methods()

@app.route('/api/multiple/encrypt', methods=['POST'])
def multiple_encrypt():
    try:
        data = request.json
        mode = data.get('mode', 'double')
        keys = data.get('keys', [])
        input_data = data.get('input', '')
        input_type = data.get('type', 'binary')
        
        # 验证密钥
        for key in keys:
            if not validate_binary(key, 16):
                return jsonify({'error': '所有密钥必须是16位二进制数'}), 400
        
        key_ints = [int(key, 2) for key in keys]
        
        if input_type == 'binary':
            if not validate_binary(input_data, 16):
                return jsonify({'error': '输入数据必须是16位二进制数'}), 400
            plaintext = int(input_data, 2)
            
            if mode == 'double':
                if len(key_ints) < 2:
                    return jsonify({'error': '双重加密需要2个密钥'}), 400
                ciphertext = saes.double_encrypt_block(plaintext, key_ints[0], key_ints[1])
            else:  # triple
                if len(key_ints) < 3:
                    return jsonify({'error': '三重加密需要3个密钥'}), 400
                ciphertext = saes.triple_encrypt_block(plaintext, key_ints[0], key_ints[1], key_ints[2])
            
            result = {
                'binary': format(ciphertext, '016b'),
                'hex': format(ciphertext, '04X')
            }
        else:
            if mode == 'double':
                if len(key_ints) < 2:
                    return jsonify({'error': '双重加密需要2个密钥'}), 400
                ciphertext = saes.double_encrypt_text(input_data, key_ints[0], key_ints[1])
            else:  # triple
                if len(key_ints) < 3:
                    return jsonify({'error': '三重加密需要3个密钥'}), 400
                ciphertext = saes.triple_encrypt_text(input_data, key_ints[0], key_ints[1], key_ints[2])
            
            hex_representation = ' '.join([format(ord(c), '02X') for c in ciphertext])
            result = {
                'text': ciphertext,
                'hex': hex_representation
            }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/multiple/decrypt', methods=['POST'])
def multiple_decrypt():
    try:
        data = request.json
        mode = data.get('mode', 'double')
        keys = data.get('keys', [])
        input_data = data.get('input', '')
        input_type = data.get('type', 'binary')
        
        # 验证密钥
        for key in keys:
            if not validate_binary(key, 16):
                return jsonify({'error': '所有密钥必须是16位二进制数'}), 400
        
        key_ints = [int(key, 2) for key in keys]
        
        if input_type == 'binary':
            if not validate_binary(input_data, 16):
                return jsonify({'error': '输入数据必须是16位二进制数'}), 400
            ciphertext = int(input_data, 2)
            
            if mode == 'double':
                if len(key_ints) < 2:
                    return jsonify({'error': '双重解密需要2个密钥'}), 400
                plaintext = saes.double_decrypt_block(ciphertext, key_ints[0], key_ints[1])
            else:  # triple
                if len(key_ints) < 3:
                    return jsonify({'error': '三重解密需要3个密钥'}), 400
                plaintext = saes.triple_decrypt_block(ciphertext, key_ints[0], key_ints[1], key_ints[2])
            
            result = {
                'binary': format(plaintext, '016b'),
                'ascii': chr((plaintext >> 8) & 0xFF) + chr(plaintext & 0xFF)
            }
        else:
            if mode == 'double':
                if len(key_ints) < 2:
                    return jsonify({'error': '双重解密需要2个密钥'}), 400
                plaintext = saes.double_decrypt_text(input_data, key_ints[0], key_ints[1])
            else:  # triple
                if len(key_ints) < 3:
                    return jsonify({'error': '三重解密需要3个密钥'}), 400
                plaintext = saes.triple_decrypt_text(input_data, key_ints[0], key_ints[1], key_ints[2])
            
            result = {
                'text': plaintext
            }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# CBC模式API - 添加缺失的CBC方法
def add_cbc_methods():
    """为SAES类添加CBC相关方法"""
    
    def generate_iv(self):
        """生成16位随机初始向量"""
        return random.randint(0, 65535)
    
    def cbc_encrypt(self, plaintext_blocks, key, iv):
        """CBC模式加密"""
        ciphertext_blocks = []
        previous_block = iv

        for block in plaintext_blocks:
            # 明文块与前一个密文块异或
            xored_block = block ^ previous_block
            # 加密
            encrypted_block = self.encrypt_block(xored_block, key)
            ciphertext_blocks.append(encrypted_block)
            previous_block = encrypted_block

        return ciphertext_blocks

    def cbc_decrypt(self, ciphertext_blocks, key, iv):
        """CBC模式解密"""
        plaintext_blocks = []
        previous_block = iv

        for block in ciphertext_blocks:
            # 解密
            decrypted_block = self.decrypt_block(block, key)
            # 与前一个密文块异或得到明文
            plaintext_block = decrypted_block ^ previous_block
            plaintext_blocks.append(plaintext_block)
            previous_block = block

        return plaintext_blocks
    
    def encrypt_text_cbc(self, plaintext, key, iv):
        """使用CBC模式加密文本"""
        blocks = self.text_to_blocks(plaintext)
        cipher_blocks = self.cbc_encrypt(blocks, key, iv)
        return self.blocks_to_text(cipher_blocks)
    
    def decrypt_text_cbc(self, ciphertext, key, iv):
        """使用CBC模式解密密文"""
        blocks = self.text_to_blocks(ciphertext)
        plain_blocks = self.cbc_decrypt(blocks, key, iv)
        return self.blocks_to_text(plain_blocks)
    
    # 将这些方法添加到SAES类
    saes.generate_iv = generate_iv.__get__(saes, SAES)
    saes.cbc_encrypt = cbc_encrypt.__get__(saes, SAES)
    saes.cbc_decrypt = cbc_decrypt.__get__(saes, SAES)
    saes.encrypt_text_cbc = encrypt_text_cbc.__get__(saes, SAES)
    saes.decrypt_text_cbc = decrypt_text_cbc.__get__(saes, SAES)

# 添加CBC方法
add_cbc_methods()

@app.route('/api/cbc/encrypt', methods=['POST'])
def cbc_encrypt():
    try:
        data = request.json
        key_str = data.get('key', '')
        iv_str = data.get('iv', '')
        plaintext = data.get('input', '')
        
        if not validate_binary(key_str, 16):
            return jsonify({'error': '密钥必须是16位二进制数'}), 400
        
        if not validate_binary(iv_str, 16):
            return jsonify({'error': 'IV必须是16位二进制数'}), 400
        
        key = int(key_str, 2)
        iv = int(iv_str, 2)
        
        ciphertext = saes.encrypt_text_cbc(plaintext, key, iv)
        
        # 获取块信息用于显示
        blocks = saes.text_to_blocks(plaintext)
        cipher_blocks = saes.cbc_encrypt(blocks, key, iv)
        
        result = {
            'text': ciphertext,
            'blocks': [format(block, '016b') for block in cipher_blocks],
            'blocks_hex': [format(block, '04X') for block in cipher_blocks]
        }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/cbc/decrypt', methods=['POST'])
def cbc_decrypt():
    try:
        data = request.json
        key_str = data.get('key', '')
        iv_str = data.get('iv', '')
        ciphertext = data.get('ciphertext', '')
        
        if not validate_binary(key_str, 16):
            return jsonify({'error': '密钥必须是16位二进制数'}), 400
        
        if not validate_binary(iv_str, 16):
            return jsonify({'error': 'IV必须是16位二进制数'}), 400
        
        key = int(key_str, 2)
        iv = int(iv_str, 2)
        
        plaintext = saes.decrypt_text_cbc(ciphertext, key, iv)
        
        result = {
            'text': plaintext
        }
        
        return jsonify({'success': True, 'result': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# 中间相遇攻击API
@app.route('/api/attack/meet-middle', methods=['POST'])
def meet_middle_attack():
    try:
        data = request.json
        plaintexts = data.get('plaintexts', [])
        ciphertexts = data.get('ciphertexts', [])

        if not plaintexts or not ciphertexts:
            return jsonify({'error': '需要提供明密文对'}), 400

        if len(plaintexts) != len(ciphertexts):
            return jsonify({'error': '明密文对数量不匹配'}), 400

        # 执行中间相遇攻击
        possible_keys = mitm_attack.attack(plaintexts, ciphertexts, max_keys=10)

        # 格式化结果
        result_keys = []
        for k1, k2 in possible_keys:
            k1_bin = format(k1, '016b')
            k2_bin = format(k2, '016b')
            result_keys.append({
                'k1_bin': k1_bin,
                'k1_hex': format(k1, '04X'),
                'k2_bin': k2_bin,
                'k2_hex': format(k2, '04X'),
                'total_key': k1_bin + k2_bin
            })

        # 验证第一个密钥对
        verification = None
        if result_keys:
            k1, k2 = possible_keys[0]
            test_plain = plaintexts[0]
            expected_cipher = ciphertexts[0]
            actual_cipher = saes.double_encrypt_text(test_plain, k1, k2)
            verification = {
                'plaintext': test_plain,
                'expected_cipher': expected_cipher,
                'actual_cipher': actual_cipher,
                'match': actual_cipher == expected_cipher
            }

        return jsonify({
            'success': True,
            'possible_keys': result_keys,
            'verification': verification
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# 工具API
@app.route('/api/tools/generate_iv', methods=['GET'])
def generate_iv():
    """生成随机IV"""
    iv = saes.generate_iv()
    return jsonify({
        'success': True,
        'iv': format(iv, '016b'),
        'iv_hex': format(iv, '04X')
    })

@app.route('/api/tools/generate_key', methods=['GET'])
def generate_key():
    """生成随机密钥"""
    key = random.randint(0, 65535)
    return jsonify({
        'success': True,
        'key': format(key, '016b'),
        'key_hex': format(key, '04X')
    })

# 创建templates目录并确保index.html存在
def ensure_template_exists():
    """确保模板文件存在"""
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # 如果templates目录中没有index.html，从当前目录复制
    if not os.path.exists('templates/index.html'):
        if os.path.exists('index.html'):
            with open('index.html', 'r', encoding='utf-8') as f:
                content = f.read()
            with open('templates/index.html', 'w', encoding='utf-8') as f:
                f.write(content)
            print("已复制index.html到templates目录")
        else:
            print("警告: 未找到index.html文件")

if __name__ == '__main__':
    # 确保模板文件存在
    ensure_template_exists()
    
    print("S-AES加密解密系统启动中...")
    print("访问地址: http://localhost:5000")
    app.run(debug=True, port=5000)