// From the software distribution accompanying the textbook
// "A Practical Introduction to Data Structures and Algorithm Analysis,
// Third Edition (C++)" by Clifford A. Shaffer.
// Source code Copyright (C) 2007-2011 by Clifford A. Shaffer.

// Bubble Sort implementation and timing test driver

#include "book.h"
#include <iostream>
#include <vector>
#include <random>
// Include comparator functions
#include "compare.h"

struct IntLess {
    static bool prior(int a, int b) {
        return a < b;
    }
};
// Bubble sort implementation
template <typename E, typename Comp>
void bubsort(E A[], int n) { // Bubble Sort
    for (int i = 0; i < n - 1; i++)     // Bubble up i'th record
        for (int j = n - 1; j > i; j--)
            if (Comp::prior(A[j], A[j - 1]))
                swap(A, j, j - 1);
}

template <typename E, typename Comp>
void sort(E* array, int n) {
    bubsort<E, Comp>(array, n);
}

using namespace std;
int main()
{
    mt19937 rng(std::random_device{}());
    uniform_int_distribution<int> dist(1, 1000);
    vector<int> data;
    const int numElements = 1000;
    for (int i = 0; i < numElements; ++i) {
        data.push_back(dist(rng));
    }
    bubsort<int, IntLess>(data.data(), 1000);
    for (int i = 40; i < 60; i++)
    {
        cout << data[i] << " ";
    }

    return 0;
}
