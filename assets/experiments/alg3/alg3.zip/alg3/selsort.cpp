// From the software distribution accompanying the textbook
// "A Practical Introduction to Data Structures and Algorithm Analysis,
// Third Edition (C++)" by Clifford A. Shaffer.
// Source code Copyright (C) 2007-2011 by Clifford A. Shaffer.

// Selection Sort implementation and timing test driver

#include "book.h"
#include <iostream>
#include <vector>
#include <random>
// Include comparator functions
#include "compare.h"

struct IntLess {
    static bool prior(int a, int b) {
        return a < b;
    }
};
// Selection sort implementation
template <typename E, typename Comp>
void selsort(E A[], int n) { // Selection Sort
    for (int i = 0; i < n - 1; i++) {   // Select i'th record
        int lowindex = i;           // Remember its index
        for (int j = n - 1; j > i; j--)   // Find the least value
            if (Comp::prior(A[j], A[lowindex]))
                lowindex = j;           // Put it in place
        swap(A, i, lowindex);
    }
}

template <typename E, typename Comp>
void sort(E* array, int n) {
    selsort<E, Comp>(array, n);
}

using namespace std;
int main()
{
    mt19937 rng(std::random_device{}());
    uniform_int_distribution<int> dist(1, 1000);
    vector<int> data;
    const int numElements = 1000;
    for (int i = 0; i < numElements; ++i) {
        data.push_back(dist(rng));
    }
    selsort<int, IntLess>(data.data(), 1000);
    for (int i = 20; i <40;i++)
    {
        cout << data[i] << " ";
    }

    return 0;
}
