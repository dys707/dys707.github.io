import random
import math


class DiffieHellman:
    def __init__(self, min_value=100, max_value=255):
        self.min_value = min_value
        self.max_value = max_value
        self.prime = None
        self.primitive_root = None
        self.private_key = None
        self.public_key = None
        self.shared_secret = None

    def is_prime(self, n):
        """检查是否为素数"""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False

        # 检查从3到sqrt(n)的奇数
        for i in range(3, int(math.sqrt(n)) + 1, 2):
            if n % i == 0:
                return False
        return True

    def generate_prime_in_range(self):
        """在指定范围内生成素数"""
        primes = [p for p in range(self.min_value, self.max_value + 1) if self.is_prime(p)]
        if not primes:
            raise ValueError(f"在范围 {self.min_value}-{self.max_value} 内没有找到素数")
        return random.choice(primes)

    def _prime_factors(self, n):
        """找到n的所有质因数"""
        factors = set()
        # 处理2
        while n % 2 == 0:
            factors.add(2)
            n //= 2

        # 处理奇数
        i = 3
        while i * i <= n:
            while n % i == 0:
                factors.add(i)
                n //= i
            i += 2

        if n > 1:
            factors.add(n)

        return factors

    def find_primitive_root(self, p):
        """找到给定素数的原根"""
        if p == 2:
            return 1

        # 分解p-1的质因数
        phi = p - 1
        prime_factors = self._prime_factors(phi)

        # 测试每个候选数
        for g in range(2, p):
            if all(pow(g, phi // factor, p) != 1 for factor in prime_factors):
                return g
        return None

    def generate_parameters(self):
        """生成D-H参数（素数和原根）"""
        self.prime = self.generate_prime_in_range()
        self.primitive_root = self.find_primitive_root(self.prime)

        if self.primitive_root is None:
            raise ValueError(f"无法找到素数 {self.prime} 的原根")

        return self.prime, self.primitive_root

    def generate_keys(self):
        """生成私钥和公钥"""
        if self.prime is None or self.primitive_root is None:
            self.generate_parameters()

        # 生成私钥（随机数）
        self.private_key = random.randint(2, self.prime - 2)

        # 计算公钥: g^private_key mod p
        self.public_key = pow(self.primitive_root, self.private_key, self.prime)

        return self.public_key

    def compute_shared_secret(self, other_public_key):
        """计算共享密钥"""
        if self.private_key is None:
            raise ValueError("请先生成密钥对")

        # 计算共享密钥: other_public_key^private_key mod p
        self.shared_secret = pow(other_public_key, self.private_key, self.prime)
        return self.shared_secret

    def get_parameters(self):
        """获取当前参数"""
        return {
            'prime': self.prime,
            'primitive_root': self.primitive_root,
            'private_key': self.private_key,
            'public_key': self.public_key,
            'shared_secret': self.shared_secret
        }


def demonstrate_dh_exchange():
    """演示完整的D-H密钥交换过程"""
    print("=" * 60)
    print("Diffie-Hellman 密钥交换算法演示")
    print("=" * 60)

    # 创建两个通信方：Alice和Bob
    print("\n1. 初始化双方参数...")
    alice = DiffieHellman(100, 255)
    bob = DiffieHellman(100, 255)

    # 双方使用相同的素数p和原根g
    print("\n2. 生成共享参数...")
    p, g = alice.generate_parameters()
    bob.prime = p
    bob.primitive_root = g

    print(f"   共享素数 p = {p}")
    print(f"   共享原根 g = {g}")

    # 双方生成各自的密钥对
    print("\n3. 生成各自的密钥对...")
    alice_public = alice.generate_keys()
    bob_public = bob.generate_keys()

    print(f"   Alice的公钥: {alice_public}")
    print(f"   Bob的公钥: {bob_public}")
    print(f"   Alice的私钥: {alice.private_key}")
    print(f"   Bob的私钥: {bob.private_key}")

    # 双方交换公钥并计算共享密钥
    print("\n4. 交换公钥并计算共享密钥...")
    alice_secret = alice.compute_shared_secret(bob_public)
    bob_secret = bob.compute_shared_secret(alice_public)

    print(f"   Alice计算的共享密钥: {alice_secret}")
    print(f"   Bob计算的共享密钥: {bob_secret}")

    # 验证共享密钥是否相同
    print("\n5. 验证共享密钥...")
    if alice_secret == bob_secret:
        print("   ✓ 共享密钥匹配！密钥交换成功！")
        print(f"   最终共享密钥: {alice_secret}")
    else:
        print("   ✗ 共享密钥不匹配！")

    # 演示单向函数特性
    print("\n6. 单向函数特性演示...")
    print("   已知: p, g, Alice的公钥, Bob的公钥")
    print("   但无法轻易推导出:")
    print("     - Alice的私钥")
    print("     - Bob的私钥")
    print("     - 共享密钥")


def test_multiple_exchanges():
    """测试多次密钥交换"""
    print("\n" + "=" * 60)
    print("多次密钥交换测试")
    print("=" * 60)

    for i in range(3):
        print(f"\n--- 测试 #{i + 1} ---")
        alice = DiffieHellman(100, 200)
        bob = DiffieHellman(100, 200)

        # 共享参数
        p, g = alice.generate_parameters()
        bob.prime = p
        bob.primitive_root = g

        # 密钥交换
        alice_public = alice.generate_keys()
        bob_public = bob.generate_keys()
        alice_secret = alice.compute_shared_secret(bob_public)
        bob_secret = bob.compute_shared_secret(alice_public)

        print(f"素数 p: {p}")
        print(f"原根 g: {g}")
        print(f"共享密钥: {alice_secret}")
        print(f"密钥匹配: {alice_secret == bob_secret}")


if __name__ == "__main__":
    # 运行演示
    demonstrate_dh_exchange()

    # 运行多次测试
    test_multiple_exchanges()

    print("\n" + "=" * 60)
    print("D-H密钥交换算法实现完成！")
    print("=" * 60)