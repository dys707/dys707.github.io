import os
import sys
from PIL import Image
import tkinter as tk
from tkinter import filedialog, messagebox, Label, Button, Frame, Listbox, Scrollbar, Text
from tkinter import ttk


class BMPtoTIFConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("BMP 到 TIF 图像格式转换器")
        self.root.geometry("700x500")

        # 初始化变量
        self.bmp_files = []

        # 创建界面
        self.create_widgets()

    def create_widgets(self):
        # 标题
        title_label = Label(self.root, text="BMP 到 TIF 图像格式转换器",
                            font=("Arial", 16, "bold"))
        title_label.pack(pady=10)

        # 按钮框架
        button_frame = Frame(self.root)
        button_frame.pack(pady=10)

        # 选择文件按钮
        self.select_button = Button(button_frame, text="选择 BMP 文件",
                                    command=self.select_bmp_files, width=15)
        self.select_button.pack(side=tk.LEFT, padx=5)

        # 转换按钮
        self.convert_button = Button(button_frame, text="转换为 TIF",
                                     command=self.convert_to_tif, width=15)
        self.convert_button.pack(side=tk.LEFT, padx=5)

        # 清空列表按钮
        self.clear_button = Button(button_frame, text="清空列表",
                                   command=self.clear_file_list, width=15)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        # 文件列表框架
        list_frame = Frame(self.root)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # 文件列表标签
        Label(list_frame, text="已选择的 BMP 文件:").pack(anchor=tk.W)

        # 文件列表框和滚动条
        listbox_frame = Frame(list_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True)

        self.file_listbox = Listbox(listbox_frame, selectmode=tk.EXTENDED)
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = Scrollbar(listbox_frame, orient=tk.VERTICAL)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.file_listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.file_listbox.yview)

        # 输出目录选择框架
        output_frame = Frame(self.root)
        output_frame.pack(fill=tk.X, padx=20, pady=10)

        Label(output_frame, text="输出目录:").pack(anchor=tk.W)

        output_select_frame = Frame(output_frame)
        output_select_frame.pack(fill=tk.X, pady=5)

        self.output_path_var = tk.StringVar()
        self.output_path_var.set(os.path.expanduser("~/Desktop"))  # 默认桌面

        self.output_entry = tk.Entry(output_select_frame, textvariable=self.output_path_var, width=50)
        self.output_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.output_button = Button(output_select_frame, text="浏览",
                                    command=self.select_output_directory, width=10)
        self.output_button.pack(side=tk.RIGHT, padx=5)

        # 进度条和日志
        progress_frame = Frame(self.root)
        progress_frame.pack(fill=tk.X, padx=20, pady=10)

        self.progress = ttk.Progressbar(progress_frame, orient=tk.HORIZONTAL,
                                        length=100, mode='determinate')
        self.progress.pack(fill=tk.X)

        # 日志文本框
        log_frame = Frame(self.root)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        Label(log_frame, text="转换日志:").pack(anchor=tk.W)

        self.log_text = Text(log_frame, height=8, wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True)

        scrollbar_log = Scrollbar(self.log_text)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)

        self.log_text.config(yscrollcommand=scrollbar_log.set)
        scrollbar_log.config(command=self.log_text.yview)

    def select_bmp_files(self):
        """选择 BMP 文件"""
        files = filedialog.askopenfilenames(
            title="选择 BMP 文件",
            filetypes=[("BMP 文件", "*.bmp"), ("所有文件", "*.*")]
        )

        if files:
            for file_path in files:
                if file_path.lower().endswith('.bmp'):
                    if file_path not in self.bmp_files:
                        self.bmp_files.append(file_path)
                        self.file_listbox.insert(tk.END, file_path)
                        self.log(f"已添加: {os.path.basename(file_path)}")
                else:
                    self.log(f"警告: {file_path} 不是 BMP 文件，已跳过")

    def select_output_directory(self):
        """选择输出目录"""
        directory = filedialog.askdirectory(title="选择输出目录")
        if directory:
            self.output_path_var.set(directory)

    def clear_file_list(self):
        """清空文件列表"""
        self.bmp_files.clear()
        self.file_listbox.delete(0, tk.END)
        self.log("已清空文件列表")

    def convert_to_tif(self):
        """将 BMP 文件转换为 TIF 格式"""
        if not self.bmp_files:
            messagebox.showwarning("警告", "请先选择要转换的 BMP 文件")
            return

        output_dir = self.output_path_var.get()
        if not output_dir or not os.path.exists(output_dir):
            messagebox.showerror("错误", "输出目录不存在或无效")
            return

        success_count = 0
        total_count = len(self.bmp_files)

        self.progress['value'] = 0
        self.progress['maximum'] = total_count

        for i, bmp_path in enumerate(self.bmp_files):
            try:
                # 打开 BMP 图像
                with Image.open(bmp_path) as img:
                    # 生成输出文件名
                    base_name = os.path.splitext(os.path.basename(bmp_path))[0]
                    tif_path = os.path.join(output_dir, f"{base_name}.tif")

                    # 保存为 TIF 格式
                    img.save(tif_path, format='TIFF')

                    success_count += 1
                    self.log(f"成功转换: {os.path.basename(bmp_path)} -> {os.path.basename(tif_path)}")

            except Exception as e:
                self.log(f"转换失败: {os.path.basename(bmp_path)} - {str(e)}")

            # 更新进度条
            self.progress['value'] = i + 1
            self.root.update_idletasks()

        # 显示转换结果
        messagebox.showinfo("转换完成",
                            f"转换完成!\n成功: {success_count}/{total_count} 个文件\n输出目录: {output_dir}")

        # 重置进度条
        self.progress['value'] = 0

    def log(self, message):
        """添加日志消息"""
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()


def main():
    # 检查是否安装了必要的库
    try:
        from PIL import Image
    except ImportError:
        print("错误: 需要安装 Pillow 库")
        print("请运行: pip install pillow")
        sys.exit(1)

    # 创建 GUI 应用
    root = tk.Tk()
    app = BMPtoTIFConverter(root)
    root.mainloop()


if __name__ == "__main__":
    main()