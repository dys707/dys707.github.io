import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog, Scale, Button, Label, Frame
from PIL import Image, ImageTk


class GrayscaleImageProcessor:
    def __init__(self, root):
        self.root = root
        self.root.title("图像灰度变换工具 - 三种灰度转换方式")
        self.root.geometry("1000x800")

        # 初始化变量
        self.original_image = None
        self.original_color_image = None  # 保存原始彩色图像
        self.grayscale_image = None
        self.processed_image = None
        self.current_method = "weighted"  # 默认使用加权平均方法

        # 创建界面
        self.create_widgets()

    def create_widgets(self):
        # 顶部框架 - 文件操作
        top_frame = Frame(self.root)
        top_frame.pack(pady=10)

        self.load_button = Button(top_frame, text="加载图像", command=self.load_image)
        self.load_button.pack(side=tk.LEFT, padx=5)

        self.save_button = Button(top_frame, text="保存灰度图", command=self.save_image)
        self.save_button.pack(side=tk.LEFT, padx=5)

        # 图像显示区域 - 使用Frame容纳两个图像标签
        image_frame = Frame(self.root)
        image_frame.pack(pady=10, fill=tk.BOTH, expand=True)

        # 左侧显示原图
        left_frame = Frame(image_frame)
        left_frame.pack(side=tk.LEFT, padx=10, fill=tk.BOTH, expand=True)

        Label(left_frame, text="原图 (彩色)", font=("Arial", 12, "bold")).pack(pady=5)
        self.original_image_label = Label(left_frame)
        self.original_image_label.pack(fill=tk.BOTH, expand=True)

        # 右侧显示处理后的灰度图
        right_frame = Frame(image_frame)
        right_frame.pack(side=tk.RIGHT, padx=10, fill=tk.BOTH, expand=True)

        Label(right_frame, text="处理后图像 (灰度)", font=("Arial", 12, "bold")).pack(pady=5)
        self.processed_image_label = Label(right_frame)
        self.processed_image_label.pack(fill=tk.BOTH, expand=True)

        # 灰度转换方法选择
        method_frame = Frame(self.root)
        method_frame.pack(pady=10)

        Label(method_frame, text="灰度转换方法:", font=("Arial", 10, "bold")).pack(pady=5)

        method_buttons_frame = Frame(method_frame)
        method_buttons_frame.pack(pady=5)

        self.avg_button = Button(method_buttons_frame, text="平均值法", command=self.use_average_method)
        self.avg_button.pack(side=tk.LEFT, padx=5)

        self.max_button = Button(method_buttons_frame, text="最大值法", command=self.use_max_method)
        self.max_button.pack(side=tk.LEFT, padx=5)

        self.weighted_button = Button(method_buttons_frame, text="加权平均法", command=self.use_weighted_method)
        self.weighted_button.pack(side=tk.LEFT, padx=5)

        # 当前使用方法显示
        self.method_label = Label(method_frame, text="当前方法: 加权平均法", font=("Arial", 10))
        self.method_label.pack(pady=5)

        # 控制面板
        control_frame = Frame(self.root)
        control_frame.pack(pady=10)

        # 灰度值调整滑块
        self.gray_scale = Scale(control_frame, from_=0, to=255, orient=tk.HORIZONTAL,
                                label="目标平均灰度值", length=400, command=self.update_image)
        self.gray_scale.set(128)  # 默认值
        self.gray_scale.pack(pady=5)

        # 当前平均灰度值显示
        self.current_gray_label = Label(control_frame, text="当前平均灰度值: --")
        self.current_gray_label.pack(pady=5)

        # 状态栏
        self.status_label = Label(self.root, text="请加载一张图像开始处理", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM)

    def load_image(self):
        file_path = filedialog.askopenfilename(
            title="选择图像文件",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
        )

        if file_path:
            try:
                # 使用OpenCV读取图像
                self.original_image = cv2.imread(file_path)
                self.original_color_image = self.original_image.copy()  # 保存彩色原图

                if self.original_image is None:
                    raise ValueError("无法加载图像文件")

                # 使用当前选择的方法转换为灰度图像
                self.apply_grayscale_method()

                # 显示原图和处理后的图像
                self.display_images()

                # 更新当前平均灰度值显示
                self.update_current_gray_label()

                # 更新状态栏
                self.status_label.config(text=f"已加载图像: {file_path.split('/')[-1]}")

            except Exception as e:
                self.status_label.config(text=f"错误: {str(e)}")

    def save_image(self):
        if self.processed_image is not None:
            file_path = filedialog.asksaveasfilename(
                title="保存灰度图像",
                defaultextension=".png",
                filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("All files", "*.*")]
            )

            if file_path:
                cv2.imwrite(file_path, self.processed_image)
                self.status_label.config(text=f"图像已保存: {file_path.split('/')[-1]}")

    def use_average_method(self):
        """使用平均值法转换灰度图像"""
        self.current_method = "average"
        self.method_label.config(text="当前方法: 平均值法")
        self.apply_grayscale_method()
        self.display_processed_image()
        self.update_current_gray_label()
        self.status_label.config(text="已应用平均值法转换灰度图像")

    def use_max_method(self):
        """使用最大值法转换灰度图像"""
        self.current_method = "max"
        self.method_label.config(text="当前方法: 最大值法")
        self.apply_grayscale_method()
        self.display_processed_image()
        self.update_current_gray_label()
        self.status_label.config(text="已应用最大值法转换灰度图像")

    def use_weighted_method(self):
        """使用加权平均法转换灰度图像"""
        self.current_method = "weighted"
        self.method_label.config(text="当前方法: 加权平均法")
        self.apply_grayscale_method()
        self.display_processed_image()
        self.update_current_gray_label()
        self.status_label.config(text="已应用加权平均法转换灰度图像")

    def apply_grayscale_method(self):
        """应用当前选择的灰度转换方法"""
        if self.original_color_image is None:
            return

        if self.current_method == "average":
            # 平均值法: (R + G + B) / 3
            self.grayscale_image = np.mean(self.original_color_image, axis=2).astype(np.uint8)
        elif self.current_method == "max":
            # 最大值法: max(R, G, B)
            self.grayscale_image = np.max(self.original_color_image, axis=2).astype(np.uint8)
        else:  # weighted
            # 加权平均法: 0.299*R + 0.587*G + 0.114*B (OpenCV默认方法)
            self.grayscale_image = cv2.cvtColor(self.original_color_image, cv2.COLOR_BGR2GRAY)

        # 初始化处理后的图像
        self.processed_image = self.grayscale_image.copy()

    def update_image(self, value=None):
        if self.grayscale_image is not None:
            # 获取目标平均灰度值
            target_gray = self.gray_scale.get()

            # 计算当前平均灰度值
            current_mean = np.mean(self.grayscale_image)

            # 计算调整系数
            adjustment = target_gray - current_mean

            # 应用调整
            self.processed_image = np.clip(self.grayscale_image.astype(np.float32) + adjustment, 0, 255).astype(
                np.uint8)

            # 显示图像
            self.display_processed_image()

            # 更新当前平均灰度值显示
            self.update_current_gray_label()

    def update_current_gray_label(self):
        if self.processed_image is not None:
            current_mean = np.mean(self.processed_image)
            self.current_gray_label.config(text=f"当前平均灰度值: {current_mean:.2f}")

    def display_images(self):
        # 显示原图
        self.display_original_image()
        # 显示处理后的图像
        self.display_processed_image()

    def display_original_image(self):
        if self.original_image is not None:
            # 调整图像大小以适应显示区域
            h, w = self.original_image.shape[:2]
            max_size = 400  # 稍微减小以适应双列布局

            if w > h:
                new_w = max_size
                new_h = int(h * max_size / w)
            else:
                new_h = max_size
                new_w = int(w * max_size / h)

            # 调整图像大小
            resized_image = cv2.resize(self.original_image, (new_w, new_h))

            # OpenCV使用BGR格式，PIL使用RGB格式
            resized_image_rgb = cv2.cvtColor(resized_image, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(resized_image_rgb)

            # 转换为Tkinter可用的图像
            tk_image = ImageTk.PhotoImage(pil_image)

            # 更新标签
            self.original_image_label.config(image=tk_image)
            self.original_image_label.image = tk_image  # 保持引用

    def display_processed_image(self):
        if self.processed_image is not None:
            # 调整图像大小以适应显示区域
            h, w = self.processed_image.shape
            max_size = 400  # 稍微减小以适应双列布局

            if w > h:
                new_w = max_size
                new_h = int(h * max_size / w)
            else:
                new_h = max_size
                new_w = int(w * max_size / h)

            # 调整图像大小
            resized_image = cv2.resize(self.processed_image, (new_w, new_h))

            # 将OpenCV图像转换为PIL图像
            pil_image = Image.fromarray(resized_image)

            # 转换为Tkinter可用的图像
            tk_image = ImageTk.PhotoImage(pil_image)

            # 更新标签
            self.processed_image_label.config(image=tk_image)
            self.processed_image_label.image = tk_image  # 保持引用


# 创建主窗口并运行应用
if __name__ == "__main__":
    root = tk.Tk()
    app = GrayscaleImageProcessor(root)
    root.mainloop()