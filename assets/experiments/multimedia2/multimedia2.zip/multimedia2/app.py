from flask import Flask, render_template, request, send_file, jsonify
from aip import AipSpeech
import os
import uuid
from datetime import datetime
import wave
import contextlib

app = Flask(__name__)

# 百度AI配置 - 请替换为你的实际密钥
APP_ID = '120290356'
API_KEY = 'Lkm7ldWmywhzXjI5Wn2gpG4H'
SECRET_KEY = 'gWA7qam1CjBC2JqMMiqkAE46mJgYI2A9'

# 初始化AipSpeech对象
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

# 确保目录存在
AUDIO_DIR = os.path.join(os.path.dirname(__file__), 'static', 'audio')
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(AUDIO_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 发音人选项
VOICE_OPTIONS = {
    0: "女声",
    1: "男声",
    3: "情感合成-度逍遥",
    4: "情感合成-度丫丫",
    5: "情感合成-度小娇",
    103: "情感合成-度米朵",
    106: "情感合成-度博文"
}

# 语音识别语言选项
LANGUAGE_OPTIONS = {
    1537: "普通话",
    1737: "英语",
    1637: "粤语",
    1837: "重庆话"
}


def get_audio_duration(file_path):
    """获取音频文件时长"""
    try:
        with contextlib.closing(wave.open(file_path, 'r')) as f:
            frames = f.getnframes()
            rate = f.getframerate()
            duration = frames / float(rate)
            return duration
    except:
        return 0


@app.route('/')
def index():
    return render_template('index.html',
                           voice_options=VOICE_OPTIONS,
                           language_options=LANGUAGE_OPTIONS)


# 现有的语音合成路由
@app.route('/synthesize', methods=['POST'])
def synthesize_speech():
    try:
        data = request.json
        text = data.get('text', '')
        speed = int(data.get('speed', 5))
        pitch = int(data.get('pitch', 5))
        volume = int(data.get('volume', 5))
        person = int(data.get('person', 0))

        if len(text) > 1024:
            return jsonify({
                'success': False,
                'message': '文本长度不能超过1024个字符'
            })

        filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}.mp3"
        filepath = os.path.join(AUDIO_DIR, filename)

        result = client.synthesis(
            text,
            'zh',
            1,
            {
                'spd': speed,
                'pit': pitch,
                'vol': volume,
                'per': person
            }
        )

        if not isinstance(result, dict):
            with open(filepath, 'wb') as f:
                f.write(result)

            return jsonify({
                'success': True,
                'message': '语音合成成功',
                'audio_url': f'/static/audio/{filename}'
            })
        else:
            return jsonify({
                'success': False,
                'message': f'合成失败: {result}'
            })

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'服务器错误: {str(e)}'
        })


# 新增语音识别路由
@app.route('/recognize', methods=['POST'])
def recognize_speech():
    try:
        # 检查是否有文件上传
        if 'audio_file' not in request.files:
            return jsonify({
                'success': False,
                'message': '没有上传文件'
            })

        audio_file = request.files['audio_file']

        # 检查文件名
        if audio_file.filename == '':
            return jsonify({
                'success': False,
                'message': '未选择文件'
            })

        # 检查文件格式
        allowed_extensions = {'wav', 'pcm', 'amr', 'm4a'}
        file_extension = audio_file.filename.rsplit('.', 1)[1].lower() if '.' in audio_file.filename else ''

        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': f'不支持的文件格式。请上传以下格式: {", ".join(allowed_extensions)}'
            })

        # 保存上传的文件
        filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}.{file_extension}"
        filepath = os.path.join(UPLOAD_DIR, filename)
        audio_file.save(filepath)

        # 获取识别语言参数
        language = request.form.get('language', '1537')

        # 读取音频文件
        def get_file_content(file_path):
            with open(file_path, 'rb') as fp:
                return fp.read()

        # 调用百度语音识别API
        result = client.asr(
            get_file_content(filepath),
            'wav' if file_extension == 'wav' else file_extension,
            16000,  # 采样率
            {
                'dev_pid': int(language),  # 语言模型
            }
        )

        # 处理识别结果
        if result['err_no'] == 0:
            recognized_text = result['result'][0]

            # 获取音频时长
            duration = get_audio_duration(filepath)

            return jsonify({
                'success': True,
                'message': '语音识别成功',
                'text': recognized_text,
                'duration': round(duration, 2),
                'file_size': os.path.getsize(filepath)
            })
        else:
            error_msg = result['err_msg']
            # 删除上传的文件
            if os.path.exists(filepath):
                os.remove(filepath)

            return jsonify({
                'success': False,
                'message': f'识别失败: {error_msg}'
            })

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'服务器错误: {str(e)}'
        })


# 音频文件服务路由
@app.route('/static/audio/<filename>')
def serve_audio(filename):
    return send_file(os.path.join(AUDIO_DIR, filename))


@app.route('/static/uploads/<filename>')
def serve_upload(filename):
    return send_file(os.path.join(UPLOAD_DIR, filename))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)