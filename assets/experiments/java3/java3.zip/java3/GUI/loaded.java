package GUI;

import javax.swing.*;

import com.mysql.cj.x.protobuf.MysqlxCrud.Delete;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loaded extends JFrame {
	 private JComboBox<String> comboBox;
	 private JPanel resultPanel; // 用于显示查询结果
	 private JPanel basketPanel;//用于跳转购物车面板
	 private JPanel buyPanel;
	 private JPanel mainPanel;
	 private List<JLabel> labels = new ArrayList<>();//存储已选
	 private CardLayout cardLayout = new CardLayout(); // 使用卡片布局切换视图
	 private Map<String, JLabel> StringMapLabel = new HashMap<>();//为删除面板做标签值
	 private Map<JLabel, String> LabelMapString = new HashMap<>();
	 private List<String> goodsList=new ArrayList<String>();//选择的商品的列表

    public loaded(String userName) {
        setTitle("你好"+userName+", 欢迎使用本二手平台...");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        
        // 主容器使用卡片布局
        mainPanel = new JPanel(cardLayout);
        
       
        // 初始化查询结果面板
        JScrollPane result=new JScrollPane();
        resultPanel = new JPanel();
        resultPanel.setLayout(new BoxLayout(resultPanel, BoxLayout.Y_AXIS));
        result=createScrollablePanel(resultPanel);
        mainPanel.add(result, "QUERY_VIEW");
        
        // 初始化购物车面板
        JScrollPane basket=new JScrollPane();
        basketPanel = new JPanel();
        basketPanel.setLayout(new BoxLayout(basketPanel, BoxLayout.Y_AXIS));
        basket=createScrollablePanel(basketPanel);
        mainPanel.add(basket, "BASKET_VIEW");
        
        //初始化购买面板
        JScrollPane buy=new JScrollPane();
        buyPanel = new JPanel();
        buyPanel.setLayout(new BoxLayout(buyPanel, BoxLayout.Y_AXIS));
        buy=createScrollablePanel(buyPanel);
        mainPanel.add(buy,"BUY_VIEW");

        // 定义布局约束
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 边距
        gbc.anchor = GridBagConstraints.NORTHWEST;// 组件对齐到左上角
        gbc.fill = GridBagConstraints.HORIZONTAL;  // 水平填充

        //欢迎title
        JLabel label = new JLabel("欢迎使用本二手交易平台");
        // 创建一个新的字体对象，设置字体为默认字体，样式为普通，字号为 30
        Font font = new Font(label.getFont().getName(), Font.PLAIN, 30);
        label.setFont(font);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // 跨两列
        add(label, gbc);
        
        // 添加下拉选择框
        gbc.gridwidth = 1; // 重置跨列
        String[] options = {"电子产品", "生活用品", "学习用品"};
        comboBox = new JComboBox<>(options);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(comboBox, gbc);
        
      
        // 添加按钮查询
        JButton Select= new JButton("查询售卖产品");
       // Select.setBackground(Color.BLUE);
        Select.setPreferredSize(new Dimension(60, 40));
        Select.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(Select, gbc);
        Select.addActionListener(e -> showSelect(userName));
        // 添加按钮去购物车
        JButton goToBasketButton= new JButton("去购物车");
       // Select.setBackground(Color.BLUE);
        goToBasketButton.setPreferredSize(new Dimension(100, 40));
        goToBasketButton.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(goToBasketButton, gbc);
        goToBasketButton.addActionListener(e -> {
			try {
				goToBasket(userName);
			} catch (SQLException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
		});
        //添加按钮我有物品挂网
        JButton addButton= new JButton("我有物品挂网");
        addButton.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        // Select.setBackground(Color.BLUE);
         addButton.setPreferredSize(new Dimension(150, 40));
         addButton.addActionListener(e->add(userName));
         gbc.gridx = 2;
         gbc.gridy = 1;
         add(addButton, gbc);
         Select.addActionListener(e -> showSelect(userName));
         //添加按钮个人中心
         JButton myselfButton= new JButton("个人中心");
         // Select.setBackground(Color.BLUE);
         myselfButton.setFont(new Font("微软雅黑", Font.PLAIN, 16));
          myselfButton.setPreferredSize(new Dimension(120, 40));
          myselfButton.addActionListener(e->{
			try {
				myself(userName);
			} catch (SQLException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
		});
          gbc.gridx = 3;
          gbc.gridy = 1;
          add(myselfButton, gbc);
          Select.addActionListener(e -> showSelect(userName));
     // 添加主内容面板
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(mainPanel, gbc);


        setVisible(true);
    }
    private void myself(String userName) throws SQLException {
		// TODO 自动生成的方法存根
    	person me=new person(userName);
	
	}
	private void  add(String userName) {
		SwingUtilities.invokeLater(() -> {
			 addGoods updateFrame = new addGoods(userName);//String username,String address, String goodsName,int stock,float price,String type
			    updateFrame.setVisible(true); // 再次确认可见性
	    });
		
	}
	private JScrollPane createScrollablePanel(JPanel panel) {
		 JScrollPane scrollPane = new JScrollPane(panel);
  
 
		 scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        return scrollPane;
    }
    private void showSelect(String username) {
    	
     	// TODO 自动生成的方法存根
     	resultPanel.removeAll(); // 清空旧内容
     	String selectedItem = (String)comboBox.getSelectedItem();
     	link data=new link();
    

     	// 添加标题
     	JLabel title = new JLabel("名称    单价    库存      卖家");
     	title.setFont(new Font("微软雅黑", Font.PLAIN, 20));
     	resultPanel.add(title);
     	 resultPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
         resultPanel.add(Box.createVerticalStrut(6)); // 垂直间距
     	//resultPanel.add(new JSeparator());

        // ---------- 2. 添加分隔线 ----------
	          resultPanel.add(new JSeparator(SwingConstants.HORIZONTAL));
	          //resultPanel.add(Box.createVerticalStrut(20)); // 垂直间距
     	try {
     		List<product> products=data.getProductsByType(selectedItem);
     		//遍历列表
     		
 			 for (int i = 0; i < products.size(); i++) {
 			
 				JPanel itemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5)); // 左对齐，水平间距10
 				
	            product p = products.get(i);
	            JLabel label = new JLabel("                    "+p.getName()+"     "+p.getPrice()+"     "+p.getStock()+"     "+p.getSaler());
		        label.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        itemPanel.add(label);
		       
 		          
 		      // 添加选择按钮
 		        JCheckBox addBox = new JCheckBox("加入购物车");
 		        addBox.setFont(new Font("微软雅黑", Font.PLAIN, 16));
 		        addBox.addActionListener(e -> addBasket(label,p.getName()));
 		        itemPanel.add(addBox);
 		        
 		        //添加直接购买
 		        JCheckBox buyNow = new JCheckBox("直接购买");
 		        buyNow.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        buyNow.addActionListener(e -> {
		            addBasket(label, p.getName());  // 新增此行
		            buy(p.getName(), username,p.getStock());
		        });
		        itemPanel.add(buyNow);
		         //做添加到itemPanel
		        
		       
		        
		        resultPanel.add(itemPanel); //  添加商品项到结果面板
		        resultPanel.add(Box.createVerticalStrut(5)); // 添加间距
 	       
 		        }
 			
     		
     		
     	}catch (Exception e) {
     		JOptionPane.showMessageDialog(this, "加载失败","错误", JOptionPane.ERROR_MESSAGE);
 		}
     	cardLayout.show(mainPanel, "QUERY_VIEW");
        resultPanel.revalidate();//刷新布局
        resultPanel.repaint();
   	}
    	
    	 
	
    private void goToBasket(String username) throws SQLException {
    	 basketPanel.removeAll();
    	 JLabel asJLabel=new JLabel("购物车内容：(物品     单价     库存     卖家)");
    	 asJLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
    	
         basketPanel.add(asJLabel);
         basketPanel.add(new JSeparator());
         link dataLink=new link();
       //用户地址
  		try {
  			if(dataLink.getOderByName(username)!=null) {
  				JLabel orderAddress =new JLabel("确认我的地址： "+dataLink.getOderByName(username));
  				orderAddress.setFont(new Font("微软雅黑", Font.PLAIN, 16));
  				basketPanel.add(orderAddress);
  			}
 			
 		} catch (SQLException e) {
 			// TODO 自动生成的 catch 块
 			e.printStackTrace();
 		}
         basketPanel.add(new JSeparator());
  
         String goodsString;
         int stock;
         for (JLabel label : labels) {
       
             JPanel itemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
             itemPanel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
             itemPanel.add(label);
          
             //添加删除按钮和选择按钮和刷新按钮
            
             JButton deleButton=new JButton("删除");
             deleButton.setFont(new Font("微软雅黑", Font.PLAIN, 12));
             deleButton.addActionListener(e->Delete(itemPanel,label));
             itemPanel.add(deleButton);
             
            
             JButton chooseButton=new JButton("购买");
             chooseButton.setFont(new Font("微软雅黑", Font.PLAIN, 12));
             //实现购买逻辑
             goodsString=LabelMapString.get(label);
             List<product> product=dataLink.getProductsByName(goodsString);
             product product2=product.get(0);
             chooseButton.addActionListener(e ->buy(LabelMapString.get(label),username,product2.getStock()));
             itemPanel.add(chooseButton);
             basketPanel.add(itemPanel);
             
            
         }
         JButton flushButton=new JButton("刷新");
        // flushButton.addActionListener();
         
         
         cardLayout.show(mainPanel, "BASKET_VIEW");
         basketPanel.revalidate();
         basketPanel.repaint();
     }
    private void flush(JPanel panel) {
    	panel.revalidate();
    	panel.repaint();
		
	}
    private void Delete(JPanel panel,JLabel label) {
    	
    	basketPanel.remove(panel);
    	goodsList.remove(LabelMapString.get(label));
    	labels.remove(label);
        basketPanel.revalidate();//刷新界面！
        basketPanel.repaint();
    }

    
    private void addBasket(JLabel laber,String goodsName) {
	    StringMapLabel.put(goodsName,laber);
    	LabelMapString.put(laber, goodsName);
		labels.add(laber);
		goodsList.add(goodsName);

      
    	
    }

   
    
    private void buy(String goodsName,String username,int stock) {
    	if(stock==0) {
    		Window parentWindow = SwingUtilities.getWindowAncestor(resultPanel);
	        JOptionPane.showMessageDialog(parentWindow, "购买失败:库存为零" , "错误", JOptionPane.ERROR_MESSAGE);
	        return ;
    	}
    	
    	buyPanel.removeAll();
    	JLabel aSJLabel=new JLabel("购买：   名称           单价           库存           卖家");
    	aSJLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        buyPanel.add(aSJLabel);
        buyPanel.add(new JSeparator());
        link data=new link();
        //显示商品信息：
        JLabel orderlJLabel=new JLabel();
        orderlJLabel=StringMapLabel.get(goodsName);
        buyPanel.add(orderlJLabel);
 		
 		//卖家地址
 		try {
 			if(data.getSalerByName(goodsName)!=null) {
 				JLabel salerAddress =new JLabel("卖家地址： "+data.getSalerByName(goodsName));
 				buyPanel.add(salerAddress);
 			}
			
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
 		//将订单信息插入到order表中
		try {
			if(data.getOderByName(username)!=null) {
				data.foundOrder(goodsName, username,data.getSalerByName(goodsName)) ;
				data.decreaseOrder(goodsName, username);
				  Window parentWindow = SwingUtilities.getWindowAncestor(resultPanel);
			        JOptionPane.showMessageDialog(parentWindow, "购买成功！");
			}
			
			
			
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			
			
		}
		
        cardLayout.show(mainPanel, "BUY_VIEW");
        buyPanel.revalidate();
        buyPanel.repaint();
   
    }

 
}