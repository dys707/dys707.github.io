package GUI;

import javax.swing.*;
import java.awt.*;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.List;

public class InfoDialog extends JDialog {

	   static JLabel label;
	   private List<JLabel> labels;
	    public InfoDialog(JFrame parent,List list) {
	   
	        super(parent, "详细信息", true); // true 表示模态对话框
	     	labels=list;
	        setSize(400, 300);
	        setLocationRelativeTo(parent); // 居中于父窗口

	        // 设置布局
	        JPanel panel = new JPanel(new BorderLayout(10, 10));
	        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

	        
	        // 添加关闭按钮
	        JButton closeButton = new JButton("关闭");
	        closeButton.addActionListener(e -> dispose()); // 关闭窗口
	        
	        
	        for(int i=0;i<list.size();i++) {
	        	JPanel itemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5)); // 左对齐，水平间距10
		        JLabel lab=labels.getLast();
	 	       
		        lab.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        itemPanel.add(lab);
		        panel.add(itemPanel, BorderLayout.CENTER);
	        }
	        
	        
	        //添加购买按钮
	        JButton buyingButton= new JButton("购买");
	        panel.add(buyingButton);
	        panel.add(closeButton, BorderLayout.SOUTH);
	      

	        add(panel);
	    }
	
			
				
	        
	        

	    
	}


