package GUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.SwingUtilities;


public class main {
	public static void main(String[] args) throws SQLException {
		// TODO 自动生成的方法存根
		
		
	//person asPerson = new person("王小明");
	//test aTest=new test();
	//loaded as=new loaded("江遇");
		load asLoad=new load();//从这里进入，开始登录与注册
		
	}

}
