package GUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class change extends JFrame{

	
 public	change (String name,String pass,String addr,String phone) {
	 setTitle("更改信息");
     setSize(600, 400);
     setLocationRelativeTo(null); // 居中显示
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // 关键设置：仅关闭当前窗口
	

		JLabel nameField=new JLabel(name);
		JTextField passField = new JTextField(20);
		passField.setText(pass); // 设置默认手机号
		JTextField addrField = new JTextField(20);
		addrField.setText(addr); // 设置默认手机号
		JTextField phoneField = new JTextField(20);
		phoneField.setText(phone); // 设置默认手机号
		JButton sureButton = new JButton("确定");
		
		Font fieldFont = new Font("微软雅黑", Font.PLAIN, 14);
		Font buttonFont = new Font("微软雅黑", Font.PLAIN, 14);
		JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 组件间距
        gbc.anchor = GridBagConstraints.WEST;

        // 用户名行
        gbc.gridy = 0;
        mainPanel.add(createLabel("用户名:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(nameField, gbc);

        // 密码行
        gbc.gridy = 1;
        gbc.gridx = 0;
        mainPanel.add(createLabel("密码（6位数字）:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(passField, gbc);

        // 地址行
        gbc.gridy = 2;
        gbc.gridx = 0;
        mainPanel.add(createLabel("地址:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(addrField, gbc);

        // 电话行
        gbc.gridy = 3;
        gbc.gridx = 0;
        mainPanel.add(createLabel("电话:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(phoneField, gbc);

        // 按钮行
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(sureButton);
        sureButton.addActionListener(e->sure(name,passField.getText().trim(),addrField.getText().trim(),phoneField.getText().trim()));
   

        // 主布局
        getContentPane().setLayout(new BorderLayout(10, 10));
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setVisible(true); // 添加此行
	 
		
	}
    private boolean sure(String name,String pass, String addr, String phone) {
		// TODO 自动生成的方法存根
    	// 非空检查
    	boolean OK=false;
        if (name.isEmpty() || pass.isEmpty() || addr.isEmpty() || phone.isEmpty()) {
            showError("所有字段都必须填写");
            return false; 
        }

        // 密码强度检查（必须为6位）
        if (pass.length() == 5) {
            showError("密码必须是6位数字");
            return false; 

        }

        // 电话号码格式验证
        if (!Pattern.matches("^1[3-9]\\d{9}$", phone)) {
            showError("请输入有效的11位手机号码");
            return false; 
     
        }
        final String URL = "jdbc:mysql://localhost:3306/trade";
    	final String USER = "root";
    	final String PASSWORD = "042519";
    	String sql2 = "update user set password=?,address=?,phoneNumber=? where name=?";
    	try(Connection conn=DriverManager.getConnection(URL,USER,PASSWORD);
    			Statement stmt= conn.createStatement();
    			PreparedStatement pstmt = conn.prepareStatement(sql2)){
    		
    		
			pstmt.setString(1, pass);
			pstmt.setString(2, addr);
			pstmt.setString(3, phone);
			pstmt.setString(4, name);
			pstmt.executeUpdate();
			JOptionPane.showMessageDialog(this, "修改成功！", "成功", JOptionPane.INFORMATION_MESSAGE);
			OK=true;
      
	
    }catch (Exception e1) {
		// TODO: handle exception
    	JOptionPane.showMessageDialog(this, "修改似乎不成功，请检查格式", "错误", JOptionPane.ERROR_MESSAGE);
	}
    	return OK;
    	}
	private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("微软雅黑", Font.BOLD, 14));
        return label;
    }
	  private void showError(String message) {
	        JOptionPane.showMessageDialog(this, message, "输入错误", JOptionPane.ERROR_MESSAGE);
	    }


}
