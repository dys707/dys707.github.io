package GUI;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class addGoods extends JFrame{
	public addGoods(String username) {
		setTitle("更改信息");
	    setSize(600, 400);
	    setLocationRelativeTo(null); // 居中显示
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // 关键设置：仅关闭当前窗口
			JLabel nameField=new JLabel(username);
			//添加输入框：
			JTextField goodsField = new JTextField(20);
			JTextField stockField = new JTextField(20);
			JTextField priceField = new JTextField(20);
			//选择框
			JComboBox<String> typeComboBox;
			String[] types = {"电子产品", "学习用品", "生活用品"};
			typeComboBox = new JComboBox<>(types);
			typeComboBox.setSelectedIndex(0); // 默认选中第一个
			//确定键
			JButton sureButton = new JButton("确定");
			Font fieldFont = new Font("微软雅黑", Font.PLAIN, 14);
			Font buttonFont = new Font("微软雅黑", Font.PLAIN, 14);
			JPanel mainPanel = new JPanel(new GridBagLayout());
	        GridBagConstraints gbc = new GridBagConstraints();
	        mainPanel.add(sureButton,gbc);
	        gbc.insets = new Insets(5, 5, 5, 5); // 组件间距
	        gbc.anchor = GridBagConstraints.WEST;
	        // 名称行
	        gbc.gridy = 0;
	        mainPanel.add(createLabel("物品名："), gbc);
	        gbc.gridx = 1;
	        mainPanel.add(goodsField, gbc);

	        // 数量行
	        gbc.gridy = 1;
	        gbc.gridx = 0;
	        mainPanel.add(createLabel("数量："), gbc);
	        gbc.gridx = 1;
	        mainPanel.add(stockField, gbc);

	        // 价格行
	        gbc.gridy = 2;
	        gbc.gridx = 0;
	        mainPanel.add(createLabel("定价："), gbc);
	        gbc.gridx = 1;
	        mainPanel.add(priceField, gbc);
	        add(mainPanel);
	        //选择框
	        gbc.gridy = 3; // 下移一行
	        gbc.gridx = 0;
	        mainPanel.add(createLabel("类型："), gbc);
	        gbc.gridx = 1;
	        mainPanel.add(typeComboBox, gbc);
	        
	        //按钮行
	        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
	        buttonPanel.add(sureButton);
	        sureButton.addActionListener(e->{
				try {
					sure(username,goodsField.getText().trim(),stockField.getText().trim(),
							priceField.getText().trim(),typeComboBox.getSelectedItem().toString());
				} catch (SQLException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				}
			});
	        mainPanel.add(buttonPanel);
	        pack();
	        setVisible(true); // 添加此行
	}
	private void sure(String username, String goods, String stock, String price,String type) throws SQLException {
		
		try {
			int num=Integer.parseInt(stock);
			float pri=Float.parseFloat(price);
			String addressString;
			link data1=new link();
			String[] Data= new String[4];
	        Data=data1.getMessageByName(username);
	        addressString= Data[2];
	        System.out.println(addressString);
			
			////////String username,String address, String goodsName,int stock,float price,String type
			data1.foundGoods(username, addressString, goods, num, pri, type);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	
	}
	private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("微软雅黑", Font.BOLD, 14));
        return label;
    }
	
}
