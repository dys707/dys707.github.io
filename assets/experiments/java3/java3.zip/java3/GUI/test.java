package GUI;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class test extends JFrame {
    public test() throws SQLException {
    	
 link asLink=new link();
 asLink.foundOrder("摄像头","小李","重庆大学");//String goodsName,String username,String address
}
}