package GUI;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.font.LineBreakMeasurer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class person extends JFrame {
	//数据库链接常数
		final String URL = "jdbc:mysql://localhost:3306/trade";
		final String USER = "root";
		final String PASSWORD = "042519";
	//组件
		private String password=new String();
		private String phoneNumber=new String();
		private String address=new String();
		public person(String name) throws SQLException {
			// TODO 自动生成的构造函数存根
			setTitle("我的个人中心...");
			setSize(800,600);
			setLocationRelativeTo(null); //居中显示
			//主面板
	        JPanel mainPanel= new JPanel(new CardLayout());
	        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
	     
	     //从数据库获取用户信息
	        link dataLink=new link();
	        String[] message= new String[4];
	        message=dataLink.getMessageByName(name);
	      //组件初始化
	        JLabel usernameLabel = new JLabel("用户名:"+"  "+name);
	        usernameLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        JLabel passwordLabel = new JLabel("密码:"+"  "+message[1]);
	        passwordLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        JLabel addressLabel = new JLabel("地址:"+"  "+message[2]);
	        addressLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        JLabel phoneLabel = new JLabel("电话号码:"+"  "+message[3]);
	        phoneLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        password=message[1];
	        address=message[2];
	        phoneNumber=message[3];
	
	     // 添加组件到面板
	 
	        JPanel itemJPanel =new JPanel();
	        JButton changeButton =new JButton("修改个人信息");
	        changeButton.setFont(new Font("微软雅黑", Font.PLAIN, 20));
	        changeButton.setPreferredSize(new Dimension(80, 60));
	        changeButton.addActionListener(e-> sure(name,password,address,phoneNumber));
	        JButton flushButton=new JButton("刷新");
	        flushButton.setFont(new Font("微软雅黑", Font.PLAIN, 20));
	        flushButton.setPreferredSize(new Dimension(80, 60));
	        flushButton.addActionListener(e->{
				try {
					fulsh(mainPanel,name);
				} catch (SQLException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				}
			});
	        //添加到主页面
	        mainPanel.setLayout(new GridLayout(11, 1, 10, 10)); // 6行1列，间距10px
	        mainPanel.add(changeButton);
	        mainPanel.add(flushButton);
	        mainPanel.add(usernameLabel);
	        mainPanel.add(passwordLabel);
	        mainPanel.add(addressLabel);
	        mainPanel.add(phoneLabel);
	        //添加购买记录：
	        JLabel tittleJLabel = new JLabel("购买记录:（物品  价格  卖家  发货地）");
	        tittleJLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        mainPanel.add(tittleJLabel);
	        
	        List<JLabel> orders = new ArrayList<>();
	        orders= dataLink.getOrderByName(name);
	        //System.out.println(orders.size());
	        for(int i=0;i<orders.size();i++) {
	        	JLabel itemJLabel=orders.get(i);
	        	

	        	mainPanel.add(itemJLabel);
	        }
	        //添加挂网记录：
	        JLabel tittle2JLabel = new JLabel("挂网记录:（物品  价格  数量）");
	        tittle2JLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	        mainPanel.add(tittle2JLabel);
	        
	        List<JLabel> orders2 = new ArrayList<>();
	        orders2= dataLink.getGoodsByName(name);
	       // System.out.println(orders.size());
	        for(int i=0;i<orders2.size();i++) {
	        	JLabel itemJLabel=orders2.get(i);
	        	mainPanel.add(itemJLabel);
	        }
	        
	        // 添加面板到窗口
	        add(mainPanel);
	        setVisible(true);
		}
		
		private void fulsh(JPanel panel,String name) throws SQLException {
			  panel.removeAll();
			 link dataLink=new link();
		        String[] latestData= new String[4];
		        latestData=dataLink.getMessageByName(name);
		        // 3. 创建新组件
		        JLabel usernameLabel = new JLabel("用户名:"+"  "+name);
		        usernameLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        JLabel passwordLabel = new JLabel("密码:"+"  "+latestData[1]);
		        passwordLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        JLabel addressLabel = new JLabel("地址:"+"  "+latestData[2]);
		        addressLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        JLabel phoneLabel = new JLabel("电话号码:"+"  "+latestData[3]);
		        phoneLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        password=latestData[1];
		        address=latestData[2];
		        phoneNumber=latestData[3];
		        // 4. 重新添加组件
		        JButton changeButton = new JButton("修改个人信息");
		        changeButton.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		        changeButton.setPreferredSize(new Dimension(80, 60));
		        changeButton.addActionListener(e-> sure(name,password,address,phoneNumber));
		        
		        JButton flushButton = new JButton("刷新");
		        flushButton.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		        flushButton.setPreferredSize(new Dimension(80, 60));
		        flushButton.addActionListener(e -> {
					try {
						fulsh(panel, name);
					} catch (SQLException e1) {
						// TODO 自动生成的 catch 块
						e1.printStackTrace();
					}
				});
		        
		        // 5. 按布局重新组装
		       panel.setLayout(new GridLayout(11, 1, 10, 10)); // 6行1列，间距10px
		       
		 
		        panel.add(changeButton);
		        panel.add(flushButton);
		        panel.add(usernameLabel);
		        panel.add(passwordLabel);
		        panel.add(addressLabel);
		        panel.add(phoneLabel);
		        //添加购买记录：
		        JLabel tittleJLabel = new JLabel("购买记录:（物品  价格  卖家  发货地）");
		        tittleJLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        panel.add(tittleJLabel);
		        List<JLabel> orders = new ArrayList<>();
		        orders= dataLink.getOrderByName(name);
		  
		        for(int i=0;i<orders.size();i++) {
		        	JLabel itemJLabel=orders.get(i);
		        
		        	panel.add(itemJLabel);
		        }
		      //添加挂网记录：
		        JLabel tittle2JLabel = new JLabel("挂网记录:（物品  价格  数量）");
		        tittle2JLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		        panel.add(tittle2JLabel);
		        
		        List<JLabel> orders2 = new ArrayList<>();
		        orders2= dataLink.getGoodsByName(name);
		       // System.out.println(orders.size());
		        for(int i=0;i<orders2.size();i++) {
		        	JLabel itemJLabel=orders2.get(i);
		        	panel.add(itemJLabel);
		        }
		        
		        
		        // 6. 强制刷新界面
		        panel.revalidate();
		        panel.repaint();
		
		}
		private void sure(String name, String pass, String addr, String phone2) {
			SwingUtilities.invokeLater(() -> {
				 change updateFrame = new change(name, pass, addr, phone2);
				    updateFrame.setVisible(true); // 再次确认可见性
    	    });
		}
	
}
