package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Pattern;

public class regster extends JFrame {
    // 界面组件
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField addressField;
    private JTextField phoneField;
    private JButton registerButton;
    private JButton resetButton;

    public  regster() {
		// TODO 自动生成的构造函数存根
    	
    	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // 关键设置：仅关闭当前窗口
        initComponents();
        setupLayout();
        setupListeners();
        setTitle("用户注册");
        setSize(400, 300);
        setLocationRelativeTo(null); // 居中显示
    }

    private void initComponents() {
        // 初始化所有组件
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        addressField = new JTextField(20);
        phoneField = new JTextField(20);
        registerButton = new JButton("注册");
        resetButton = new JButton("重置");

        // 设置字体
        Font labelFont = new Font("微软雅黑", Font.PLAIN, 14);
        Font fieldFont = new Font("微软雅黑", Font.PLAIN, 14);
        
        // 电话号码输入限制（只能输入数字）
        phoneField.setInputVerifier(new InputVerifier() {
            @Override
            public boolean verify(JComponent input) {
                String text = ((JTextField) input).getText();
                return text.matches("\\d*"); // 仅允许数字
            }
        });
    }

    private void setupLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 组件间距
        gbc.anchor = GridBagConstraints.WEST;

        // 用户名行
        gbc.gridy = 0;
        mainPanel.add(createLabel("用户名:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(usernameField, gbc);

        // 密码行
        gbc.gridy = 1;
        gbc.gridx = 0;
        mainPanel.add(createLabel("密码（6位数字）:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(passwordField, gbc);

        // 地址行
        gbc.gridy = 2;
        gbc.gridx = 0;
        mainPanel.add(createLabel("地址:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(addressField, gbc);

        // 电话行
        gbc.gridy = 3;
        gbc.gridx = 0;
        mainPanel.add(createLabel("电话:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(phoneField, gbc);

        // 按钮行
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(resetButton);
        buttonPanel.add(registerButton);

        // 主布局
        getContentPane().setLayout(new BorderLayout(10, 10));
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("微软雅黑", Font.BOLD, 14));
        return label;
    }

    private void setupListeners() {
       
        registerButton.addActionListener(e -> {
            if (validateInput()) {
                // 添加数据库查看
            	final String URL = "jdbc:mysql://localhost:3306/trade";
            	final String USER = "root";
            	final String PASSWORD = "042519";
            	String username= usernameField.getText().trim();
            	String password = new String(passwordField.getText()).trim(); 
            	String address=addressField.getText().trim();
            	String phone=phoneField.getText().trim();
            	String sql1="SELECT * FROM trade.user where name=?";

            	try(Connection conn=DriverManager.getConnection(URL,USER,PASSWORD);
            			Statement stmt= conn.createStatement();
            			PreparedStatement pstmt = conn.prepareStatement(sql1)){
            		
            		pstmt.setString(1, username);
            		ResultSet rs = pstmt.executeQuery();
            		
            		if(rs.next()) {
            			JOptionPane.showMessageDialog(this, "用户名已存在", "错误", JOptionPane.ERROR_MESSAGE);
            		}
            		
            		
            	}catch (Exception e1) {
        			// TODO: handle exception
        		}
            	String sql2 = "INSERT INTO user (name, password,address,phoneNumber) VALUES (?, ?,?,?)";
            	try(Connection conn=DriverManager.getConnection(URL,USER,PASSWORD);
            			Statement stmt= conn.createStatement();
            			PreparedStatement pstmt = conn.prepareStatement(sql2)){
            		
            		pstmt.setString(1, username);
        			pstmt.setString(2, password);
        			pstmt.setString(3, address);
        			pstmt.setString(4, phone);
        			pstmt.executeUpdate();
        			JOptionPane.showMessageDialog(this, "注册成功！", "欢迎", JOptionPane.INFORMATION_MESSAGE);
            		loaded loaded=new loaded(username);
            	}catch (Exception e1) {
        			// TODO: handle exception
        		}
               
                clearFields();
            }
        });

        // 重置按钮事件
        resetButton.addActionListener(e -> clearFields());
    }

    private boolean validateInput() {
        // 输入验证逻辑
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String address = addressField.getText().trim();
        String phone = phoneField.getText().trim();

        // 非空检查
        if (username.isEmpty() || password.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            showError("所有字段都必须填写");
            return false;
        }

        // 密码强度检查（必须为6位）
        if (password.length() == 5) {
            showError("密码至少需要6位");
            return false;
        }

        // 电话号码格式验证
        if (!Pattern.matches("^1[3-9]\\d{9}$", phone)) {
            showError("请输入有效的11位手机号码");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "输入错误", JOptionPane.ERROR_MESSAGE);
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        addressField.setText("");
        phoneField.setText("");
    }

 
}