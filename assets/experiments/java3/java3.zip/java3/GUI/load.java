package GUI;


import javax.security.auth.login.LoginContext;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.PrivateKey;
import java.sql.*;

public class load extends JFrame{
	//数据库链接常数
	final String URL = "jdbc:mysql://localhost:3306/trade";
	final String USER = "root";
	final String PASSWORD = "042519";
    
    //GUI组件
	private JTextField usernameField;
	private JTextField passwordField;
	
	public load() {
		//初始化窗口
		setTitle("登录...");
		setSize(400,300);
        setLocationRelativeTo(null); //居中显示
        
        //主面板
        JPanel mainPanel= new JPanel(new GridLayout(4,2,10,10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
     // 组件初始化
        JLabel usernameLabel = new JLabel("用户名:");
        JLabel passwordLabel = new JLabel("密码:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        JButton loginButton = new JButton("登录");
        JButton registerButton = new JButton("注册");

        // 添加组件到面板
        mainPanel.add(usernameLabel);
        mainPanel.add(usernameField);
        mainPanel.add(passwordLabel);
        mainPanel.add(passwordField);
        mainPanel.add(loginButton);
        mainPanel.add(registerButton);
     // 按钮事件监听
        loginButton.addActionListener(e -> load());
        registerButton.addActionListener(e -> Register());

        // 添加面板到窗口
        add(mainPanel);
        setVisible(true);
	}
    private void load() {
    	
    	String username= usernameField.getText().trim();
    	String password= new String(passwordField.getText()).trim();
    	if (username.isEmpty() || password.isEmpty()) {
    		JOptionPane.showMessageDialog(this, "用户名和密码不能为空！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }
    	String sql="SELECT * FROM trade.user where name=? and password=?";
    	
    	try(Connection conn=DriverManager.getConnection(URL,USER,PASSWORD);
    			 PreparedStatement pstmt = conn.prepareStatement(sql)){
    		pstmt.setString(1, username);
    		pstmt.setString(2, password);
    		ResultSet rs = pstmt.executeQuery();
    		
    		if(rs.next()) {
    			JOptionPane.showMessageDialog(this, "登录成功！", "欢迎", JOptionPane.INFORMATION_MESSAGE);
    			new loaded(username);
    			return;
    		}
    		
    		else {
    						
    			JOptionPane.showMessageDialog(this, "该用户不存在或密码错误", "错误", JOptionPane.ERROR_MESSAGE);
    		}
    		
    	}catch (SQLException e) {
			// TODO: handle exception
		}
    	
    
    }
    private void Register() {
    	 SwingUtilities.invokeLater(() -> {
    	        new regster().setVisible(true); // 独立窗口，关闭不会影响主界面
    	    });
    	
	}
		

}
