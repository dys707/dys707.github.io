package GUI;

import java.awt.Component;
import java.awt.Window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class link extends JFrame{
	//构造函数创建link数据库
	//数据库链接常数
		final String URL = "jdbc:mysql://localhost:3306/trade";
		final String USER = "root";
		final String PASSWORD = "042519";
		   /** 根据分类查询商品 */
	    public List<product> getProductsByType(String type) throws SQLException {
	    	List<product> products = new ArrayList<>();
	    	String sql = "SELECT name,price,stock,saler FROM goods WHERE type=?";
			
			
			try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
		             PreparedStatement pstmt = conn.prepareStatement(sql)) {
		            pstmt.setString(1, type);
		            ResultSet rs = pstmt.executeQuery();

		            while (rs.next()) {
		                product product = new product();
		                product.setName(rs.getString("name"));
		                product.setPrice(rs.getFloat("price"));
		                product.setStock(rs.getInt("stock"));
		                product.setSaler(rs.getString("saler"));
		                products.add(product);
		            }
		        }
		        return products;
		    }
	    //显示购买产品的名称，价格，卖家
	    public List<product> getProductsByName(String name) throws SQLException {
	    	List<product> products = new ArrayList<>();
	    	String sql = "SELECT name,price,stock,saler FROM goods WHERE name=?";
			
			
			try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
		             PreparedStatement pstmt = conn.prepareStatement(sql)) {
		            pstmt.setString(1, name);
		            ResultSet rs = pstmt.executeQuery();

		            while (rs.next()) {
		                product product = new product();
		                product.setName(rs.getString("name"));
		                product.setPrice(rs.getFloat("price"));
		                product.setStock(rs.getInt("stock"));
		                product.setSaler(rs.getString("saler"));
		                products.add(product);
		            }
		        }
		        return products;
		    }
	  //显示顾客的地址
	    public String getOderByName(String name) throws SQLException {
	    	String address = null;
	    	String sql = "SELECT address FROM user WHERE name=?";
			
			
			try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
		             PreparedStatement pstmt = conn.prepareStatement(sql)) {
		            pstmt.setString(1, name);
		            ResultSet rs = pstmt.executeQuery();

		            while (rs.next()) {
		               address=rs.getString("address");
		               
		            }
		        }
		        return address;
		    }
	    //显示卖家地址
	    public String getSalerByName(String goodsName) throws SQLException {
	    	String address = null;
	    	String sql = "SELECT address FROM user,goods WHERE goods.name=? and saler=user.name";
			
			
			try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
		             PreparedStatement pstmt = conn.prepareStatement(sql)) {
		            pstmt.setString(1, goodsName);
		            ResultSet rs = pstmt.executeQuery();

		            while (rs.next()) {
		               address=rs.getString("address");
		               
		            }
		        }
		        return address;
		    }
	    //插入订单
	    public void foundOrder(String goodsName,String username,String address) throws SQLException {
	    	
	    	boolean fine=false;
	    
	    	String sqlSetorder ="INSERT INTO ordertable (goods, Customer, toAddress) VALUES (?,?,?)";
	    	String sqlSetsaler = "update  ordertable set ordertable.saler =( SELECT goods.saler FROM goods WHERE goods.name=?);";
			
	    	try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
	    	    conn.setAutoCommit(false); // 关闭自动提交，开启事务
	    	    try (PreparedStatement pstmt = conn.prepareStatement(sqlSetorder);
	    	         PreparedStatement pstmt2 = conn.prepareStatement(sqlSetsaler);)
	    	    		{
	    	        pstmt.setString(1, goodsName);
	    	        pstmt.setString(2, username);
	    	        pstmt.setString(3, address);
	    	        pstmt2.setString(1, goodsName);
	    	        
	    	        int rowsInserted = pstmt.executeUpdate();
	    	        int rowsUpdated = pstmt2.executeUpdate();
	    	        if (rowsInserted > 0 && rowsUpdated > 0) {
	    	            conn.commit(); // 都成功则提交事务
	    	            fine = true;
	    	        } else {
	    	            conn.rollback(); // 有失败则回滚事务
	    	        }
	    	    } catch (SQLException e) {
	    	        conn.rollback(); // 捕获到异常也回滚事务
	    	        e.printStackTrace();
	    	    }
	    	} catch (SQLException e) {
	    	    e.printStackTrace();
	    	}
}
	    //减少库存
	    public void decreaseOrder(String goodsName, String username) throws SQLException {
	        String salerString = null;
	        String sqlSelectSaler = "SELECT goods.saler FROM goods WHERE goods.name=?";
	        String sqldecrease = "update goods set stock=stock-1 where name= ? and saler=?";

	        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement pstmt = conn.prepareStatement(sqlSelectSaler);
	             PreparedStatement pstmt2 = conn.prepareStatement(sqldecrease)) {

	            // 1. 查询卖家
	            pstmt.setString(1, goodsName);
	            ResultSet rs = pstmt.executeQuery();

	            // 确保查询到卖家信息
	            if (rs.next()) {
	                salerString = rs.getString("saler");
	            } else {
	                throw new SQLException("未找到商品或卖家: " + goodsName);
	            }

	            // 2. 执行库存更新
	            pstmt2.setString(1, goodsName);
	            pstmt2.setString(2, salerString);
	            
	            // 关键修复：执行更新操作
	            int affectedRows = pstmt2.executeUpdate();
	            
	            // 检查是否成功更新
	            if (affectedRows == 0) {
	                throw new SQLException("更新失败：库存未减少（可能商品不存在或卖家不匹配）");
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw e; // 将异常向上抛出，确保调用者能感知错误
	        }
	    }
	    //通过用户名获取用户信息
	    public String[] getMessageByName(String name){
	    	String[] person = new String[4]; // 创建一个长度为 4 的 String 数组
	    	person[0]=name;
	    	 String sql="SELECT * FROM trade.user where name=?";
	         try(Connection conn=DriverManager.getConnection(URL,USER,PASSWORD);
	     			 PreparedStatement pstmt = conn.prepareStatement(sql)) {
	         	pstmt.setString(1, name);
	         	ResultSet rs = pstmt.executeQuery();
	         	while(rs.next()) {
	         		person[1]=  rs.getString("password");
	         		person[2] =rs.getString("address");
	         		person[3] =rs.getString("phoneNumber");
	         	}
	         	 
	 			
	 		} catch (Exception e) {
	 			// TODO: handle exception
	 			
	 		}
	         
			return person;
	    }
	    //更新用户的新挂网物品
  public void foundGoods(String username,String address, String goodsName,int stock,float price,String type) throws SQLException {
	    	
	    	boolean fine=false;
	    
	    	String sqlSetorder ="INSERT INTO goods (name, price, saler,stock,type) VALUES (?,?,?,?,?)";
	    	
			
	    	try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
	    	    conn.setAutoCommit(false); // 关闭自动提交，开启事务
	    	    try (PreparedStatement pstmt = conn.prepareStatement(sqlSetorder);
	    	        )
	    	    		{
	    	        pstmt.setString(1,goodsName);
	    	        pstmt.setFloat(2, price);
	    	        pstmt.setString(3, username);
	    	        pstmt.setInt(4, stock);
	    	        pstmt.setString(5, type);
	    	       
	    	        
	    	        int rowsInserted = pstmt.executeUpdate();
	    	      
	    	        if (rowsInserted > 0 ) {
	    	            conn.commit(); // 都成功则提交事务
	    	            fine = true;
	    	        } else {
	    	            conn.rollback(); // 有失败则回滚事务
	    	        }
	    	    } catch (SQLException e) {
	    	        conn.rollback(); // 捕获到异常也回滚事务
	    	        e.printStackTrace();
	    	    }
	    	} catch (SQLException e) {
	    	    e.printStackTrace();
	    	}
	    	if(fine) {
	    		JOptionPane.showMessageDialog(this, "挂网成功！", "成功", JOptionPane.INFORMATION_MESSAGE);
	    	}
}
  //通过不同用户名显示购买记录
  public List<JLabel> getOrderByName(String name) throws SQLException {
  	List<JLabel> orders = new ArrayList<>();
  	JLabel itemJLabel=new JLabel();
  	String sql = "SELECT goods,price, goods.saler, toAddress FROM goods,user,ordertable WHERE goods.name=goods and user.name=ordertable.saler "
  			+ "and ordertable.Customer=?";
		
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, name);
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	            	  JLabel orderLabel = new JLabel(rs.getString("goods")+"   "+rs.getFloat("price")+"   "+rs.getString("goods.saler")+
	            			  "     "+rs.getString("toAddress"));
	            
	               orders.add(orderLabel);
	            }
	        }
	        return orders;
	    }
  //通过不同用户名显示挂网物品
  public List<JLabel> getGoodsByName(String name) throws SQLException {
  	List<JLabel> orders = new ArrayList<>();
  	JLabel itemJLabel=new JLabel();
  	String sql = "SELECT name,price,stock FROM goods WHERE saler=? ";
  		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, name);
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	            	  JLabel orderLabel = new JLabel(rs.getString("name")+"   "+rs.getFloat("price")+"   "+rs.getInt("stock"));
	               orders.add(orderLabel);
	            }
	        }
	        return orders;
	    }
	
	
	    
	    }
