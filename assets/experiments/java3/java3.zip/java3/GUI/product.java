package GUI;

public class product {
	/** 商品数据模型 */
	
	    private int stock;
	    private String name;
	    private float price;
	    private String saler; 
	    private int number;
		public void setStock(int stock) {
			// TODO 自动生成的方法存根
			this.stock=stock;
			
		}
		public void setName(String name) {
			// TODO 自动生成的方法存根
			this.name=name;
			
		}
		public void setNumber(int number) {
			// TODO 自动生成的方法存根
			this.number=number;
			
		}
		public void setPrice(Float price) {
			// TODO 自动生成的方法存根
			this.price=price;
			
		}
		public void setSaler(String saler) {
			// TODO 自动生成的方法存根
			this.saler=saler;
			
		}
		public String getName() {
			// TODO 自动生成的方法存根
			return name;
		}
		public float getPrice() {
			// TODO 自动生成的方法存根
			return price;
		}
		public String getSaler() {
			// TODO 自动生成的方法存根
			return saler;
		}
		public int getStock() {
			// TODO 自动生成的方法存根
			return stock;
		}
		public int getNumber() {
			// TODO 自动生成的方法存根
			return number;
			
		}

	
}
