// From the software distribution accompanying the textbook
// "A Practical Introduction to Data Structures and Algorithm Analysis,
// Third Edition (C++)" by Clifford A. Shaffer.
// Source code Copyright (C) 2007-2011 by Clifford A. Shaffer.

// Test program for Prim's MCST algroithm. This version uses
// a linear scan of the distance array to decide on which vertex is next
// closest, similar to the first version of Dijkstra's algorithm
// Use any of the files in this directory with a .gph extension.
// This version is for the Adjancency List representation

#include "book.h"
#include<vector>
#include "grlist.h"

void AddEdgetoMST(int v1, int v2) {
    cout << "Add edge " << v1 << " to " << v2 << "\n";
}

int minVertex(Graph* G, int* D) { // Find min cost vertex
    int i, v = -1;
    for (i = 0; i < G->n(); i++) // Initialize v to some unvisited vertex;
        if (G->getMark(i) == UNVISITED) { v = i; break; }
    for (i = 0; i < G->n(); i++)  // Now find smallest value
        if ((G->getMark(i) == UNVISITED) && (D[i] < D[v])) v = i;
    return v;
}

void Prim(Graph* G, int* D, int s) { // Prim's MST algorithm

    int V[7];                     // Store closest vertex
    int i, w;
    for (i = 0; i < G->n(); i++) {         // Process the vertices
        int v = minVertex(G, D);
        G->setMark(v, VISITED);
        if (v != s)
            AddEdgetoMST(V[v], v);         // Add edge to MST
        if (D[v] == INFINITY) return;    // Unreachable vertices
        for (w = G->first(v); w < G->n(); w = G->next(v, w))
            if (D[w] > G->weight(v, w)) {
                D[w] = G->weight(v, w);       // Update distance
                V[w] = v;                    // Where it came from
            }
    }
}

#include<iostream>
using namespace std;
// Prim's MCST algorithm: linear scan of distance array for next vertex
// Version for Adjancency List representation
int main() {
    Graphl g(7);
    Graph* G = &g;
    int d[7];
    for (int i = 0; i < 7; i++)
    {
        d[i] = 100;
    }
    g.Init(7);
    g.first(1);
    g.setEdge(0, 1, 10);
    g.setEdge(1, 2, 10);
    g.setEdge(2, 3, 3);
    g.setEdge(2, 4, 5);
    g.setEdge(1, 4, 20);
    g.setEdge(1, 6, 2);
    g.setEdge(4, 6, 20);
    g.setEdge(4, 5, 11);
    g.setEdge(6, 5, 3);
    g.setEdge(3, 5, 15);
    Prim(G, d, 0);

    return 0;
}
